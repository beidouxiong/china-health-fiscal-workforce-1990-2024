# -*- coding: utf-8 -*-
"""把 manuscript_en.md 转成学术风格的完整 HTML（供 html-to-doc 转换）。"""
import re, html as htmlmod

SRC='D:/BaiduNetdiskDownload/年鉴分析/.workbuddy/manuscript_en.md'
DST='D:/BaiduNetdiskDownload/年鉴分析/.workbuddy/manuscript_en.html'
FIGDIR='D:/BaiduNetdiskDownload/年鉴分析/.workbuddy/results/figures'

lines=open(SRC,encoding='utf-8').read().splitlines()

def inline(s):
    # 转义，再处理 markdown 粗体/斜体/行内代码
    s=htmlmod.escape(s)
    s=re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', s)
    s=re.sub(r'(?<!\*)\*([^*]+?)\*(?!\*)', r'<em>\1</em>', s)
    s=re.sub(r'`([^`]+?)`', r'<code>\1</code>', s)
    return s

out=[]
i=0
n=len(lines)
# 标题映射
# 第一个 H1 作为论文标题（不重复放进封面）
first_h1_done=False
while i<n:
    ln=lines[i].rstrip()
    if not ln.strip():
        i+=1; continue
    # 分隔线
    if re.match(r'^---+$', ln.strip()):
        i+=1; continue
    # 标题
    m=re.match(r'^(#{1,4})\s+(.*)', ln)
    if m:
        lvl=len(m.group(1)); txt=m.group(2).strip()
        if lvl==1 and not first_h1_done:
            first_h1_done=True
            # H1 单独作为标题块（ebib）
            i+=1; continue
        tag=f'h{min(lvl,4)}'
        out.append(f'<{tag}>{inline(txt)}</{tag}>')
        i+=1; continue
    # 表格
    if ln.strip().startswith('|') and i+1<n and re.match(r'^\s*\|?[\s:\-|]+\|?\s*$', lines[i+1]):
        # 收集表头
        header=[c.strip() for c in ln.strip().strip('|').split('|')]
        i+=2
        rows=[]
        while i<n and lines[i].strip().startswith('|'):
            rows.append([c.strip() for c in lines[i].strip().strip('|').split('|')])
            i+=1
        th=''.join(f'<th>{inline(c)}</th>' for c in header)
        body=''
        for r in rows:
            tds=''.join(f'<td>{inline(c)}</td>' for c in r)
            body+=f'<tr>{tds}</tr>'
        out.append(f'<table><thead><tr>{th}</tr></thead><tbody>{body}</tbody></table>')
        continue
    # 图片占位
    imgm=re.match(r'^!\[(.*?)\]\((.*?)\)', ln.strip())
    if imgm:
        alt,path=imgm.group(1),imgm.group(2)
        out.append(f'<p class="fig"><img src="{path}" alt="{inline(alt)}" style="max-width:100%"/></p>')
        i+=1; continue
    # 普通段落：合并连续非特殊行
    para=[ln.strip()]
    i+=1
    while i<n:
        nx=lines[i].rstrip()
        if not nx.strip(): break
        if re.match(r'^(#{1,4})\s+', nx): break
        if re.match(r'^---+$', nx.strip()): break
        if nx.strip().startswith('|'): break
        if re.match(r'^!\[', nx.strip()): break
        para.append(nx.strip()); i+=1
    out.append(f'<p>{inline(" ".join(para))}</p>')

body='\n'.join(out)
# 插入4张图：在图标题附近。简单起见在对应结果小节末尾插入
# 依据文本锚点插入
def insert_after(text, anchor, snippet):
    idx=text.find(anchor)
    if idx<0: return text
    pos=text.find('</p>',idx)+4
    return text[:pos]+'\n'+snippet+text[pos:]

# 用 Pillow 直接绘制的 PNG（含完整坐标轴/图例/文字），以 base64 内联，避免 SVG->PNG 丢字
import os, base64
PNGDIR='D:/BaiduNetdiskDownload/年鉴分析/.workbuddy/results/figures_png'
def png_img(name, caption):
    p=os.path.join(PNGDIR,name)
    if not os.path.exists(p): return ''
    b64=base64.b64encode(open(p,'rb').read()).decode('ascii')
    return (f'<div class="figure"><img src="data:image/png;base64,{b64}" '
            f'alt="{htmlmod.escape(caption)}" style="max-width:100%;height:auto;"/></div>')
fig1=png_img('fig1_gini_trend.png','Figure 1. Gini coefficients of health resources')
fig2=png_img('fig2_divergence.png','Figure 2. Fiscal-workforce decoupling index')
fig3=png_img('fig3_kde.png','Figure 3. Distribution dynamics of physician density')
fig4=png_img('fig4_dagum.png','Figure 4. Dagum decomposition of physician-density inequality')
fig5=png_img('fig5_event_study.png','Figure 5. Continuous-intensity DID event study')

# 在相应锚点段落之后插入图（锚点用段落开头短语）
body=insert_after(body,'Physician-density inequality declined steadily',fig1)
body=insert_after(body,'The decoupling index is observed in 21 years from 2001',fig2)
body=insert_after(body,'Kernel density estimates show the physician distribution',fig3)
body=insert_after(body,'changed as much as its level',fig4)
body=insert_after(body,'The full event study (Figure 5) makes the identification problem visible',fig5)

title="Convergence Without Equalization: Fiscal–Workforce Decoupling in China's Health System, 1990–2024"
doc=f'''<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/>
<title>{htmlmod.escape(title)}</title>
<style>
@page {{ size: A4; margin: 2.2cm 2cm; }}
body {{ font-family: "Times New Roman", Georgia, serif; font-size: 12pt; line-height: 2.0; color:#111; max-width:100%; }}
h1.title {{ font-size: 18pt; text-align:center; font-weight:bold; margin-bottom:18pt; }}
h2 {{ font-size: 13.5pt; font-weight:bold; margin-top:18pt; margin-bottom:8pt; border-bottom:0.5pt solid #888; padding-bottom:3pt;}}
h3 {{ font-size: 12pt; font-weight:bold; margin-top:13pt; margin-bottom:5pt;}}
h4 {{ font-size: 11pt; font-weight:bold; margin-top:10pt;}}
p {{ margin: 6pt 0; text-align:justify; }}
table {{ border-collapse: collapse; width:100%; margin:10pt 0; font-size: 9.5pt; }}
th,td {{ border: 0.5pt solid #777; padding: 4pt 6pt; text-align:left; }}
th {{ font-weight:bold; }}
.figure {{ text-align:center; margin:12pt 0; }}
.figure svg {{ max-width:100%; height:auto; }}
code {{ font-family: Consolas, monospace; font-size: 10pt; }}
strong {{ font-weight:bold; }}
</style></head>
<body>
<h1 class="title">{htmlmod.escape(title)}</h1>
{body}
</body></html>'''

open(DST,'w',encoding='utf-8').write(doc)
print('HTML已生成',DST,'长度',len(doc))
print('图表中表格数',body.count('<table>'),'图片数',body.count('class="figure"'))
