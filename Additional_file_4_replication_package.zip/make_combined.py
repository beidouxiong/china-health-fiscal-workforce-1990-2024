# -*- coding: utf-8 -*-
"""把正文 + Online Appendix 合并为一份完整 HTML（15 张表、5 张图同在）。"""
import re, html as htmlmod, os, base64

BASE = 'D:/BaiduNetdiskDownload/年鉴分析/.workbuddy'
MAIN = BASE + '/manuscript_en.md'
APPX = BASE + '/online_appendix_en.md'
DST  = BASE + '/manuscript_combined.html'
FIGDIR = BASE + '/results/figures_png'

main_lines = open(MAIN, encoding='utf-8').read().splitlines()
appx_lines = open(APPX, encoding='utf-8').read().splitlines()

# 合并：正文 + 分页 + 附录。附录首个 # Online Appendix 保留为可见标题
combined = main_lines + ['', '---', ''] + appx_lines

def inline(s):
    s = htmlmod.escape(s)
    s = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', s)
    s = re.sub(r'(?<!\*)\*([^*]+?)\*(?!\*)', r'<em>\1</em>', s)
    s = re.sub(r'`([^`]+?)`', r'<code>\1</code>', s)
    s = s.replace('&lt;br&gt;', '<br/>')
    return s

out = []
i = 0
n = len(combined)
first_h1_done = False
while i < n:
    ln = combined[i].rstrip()
    if not ln.strip():
        i += 1; continue
    if re.match(r'^---+$', ln.strip()):
        i += 1; continue
    m = re.match(r'^(#{1,4})\s+(.*)', ln)
    if m:
        lvl = len(m.group(1)); txt = m.group(2).strip()
        if lvl == 1 and not first_h1_done:
            first_h1_done = True; i += 1; continue
        if lvl == 1 and txt.strip() == 'Online Appendix':
            out.append('<h1 class="appendix-h1" style="text-align:center;font-size:16pt;font-weight:bold;margin-top:24pt;">Online Appendix</h1>')
            i += 1; continue
        tag = f'h{min(lvl,4)}'
        out.append(f'<{tag}>{inline(txt)}</{tag}>'); i += 1; continue
    # 表格（正文式：表头 + 分隔行 + 数据行）
    if ln.strip().startswith('|') and i+1 < n and re.match(r'^\s*\|?[\s:\-|]+\|?\s*$', combined[i+1]):
        header = [c.strip() for c in ln.strip().strip('|').split('|')]
        i += 2
        rows = []
        while i < n and combined[i].strip().startswith('|'):
            rows.append([c.strip() for c in combined[i].strip().strip('|').split('|')]); i += 1
        th = ''.join(f'<th>{inline(c)}</th>' for c in header)
        body = ''.join('<tr>' + ''.join(f'<td>{inline(c)}</td>' for c in r) + '</tr>' for r in rows)
        out.append(f'<table><thead><tr>{th}</tr></thead><tbody>{body}</tbody></table>')
        continue
    # 图片占位（正文一般无独立图片行，保留兼容）
    imgm = re.match(r'^!\[(.*?)\]\((.*?)\)', ln.strip())
    if imgm:
        alt, path = imgm.group(1), imgm.group(2)
        out.append(f'<p class="fig"><img src="{path}" alt="{inline(alt)}" style="max-width:100%"/></p>')
        i += 1; continue
    para = [ln.strip()]; i += 1
    while i < n:
        nx = combined[i].rstrip()
        if not nx.strip(): break
        if re.match(r'^(#{1,4})\s+', nx): break
        if re.match(r'^---+$', nx.strip()): break
        if nx.strip().startswith('|'): break
        if re.match(r'^!\[', nx.strip()): break
        para.append(nx.strip()); i += 1
    out.append(f'<p>{inline(" ".join(para))}</p>')

body = '\n'.join(out)

def insert_after(text, anchor, snippet):
    idx = text.find(anchor)
    if idx < 0: return text
    pos = text.find('</p>', idx) + 4
    return text[:pos] + '\n' + snippet + text[pos:]

def png_img(name, caption):
    p = os.path.join(FIGDIR, name)
    if not os.path.exists(p): return ''
    b64 = base64.b64encode(open(p, 'rb').read()).decode('ascii')
    return (f'<div class="figure"><img src="data:image/png;base64,{b64}" '
            f'alt="{htmlmod.escape(caption)}" style="max-width:100%;height:auto;"/></div>')

figs = [
    ('Physician-density inequality declined steadily', 'fig1_gini_trend.png', 'Figure 1. Gini coefficients of health resources'),
    ('The decoupling index is observed in 21 years from 2001', 'fig2_divergence.png', 'Figure 2. Fiscal-workforce decoupling index'),
    ('Kernel density estimates show the physician distribution', 'fig3_kde.png', 'Figure 3. Distribution dynamics of physician density'),
    ('changed as much as its level', 'fig4_dagum.png', 'Figure 4. Dagum decomposition of physician-density inequality'),
    ('The full event study (Figure 5) makes the identification problem visible', 'fig5_event_study.png', 'Figure 5. Continuous-intensity DID event study'),
]
miss = []
for anchor, fname, cap in figs:
    if anchor not in body: miss.append(fname)
    body = insert_after(body, anchor, png_img(fname, cap))

title = "Convergence Without Equalization: Fiscal–Workforce Decoupling in China's Health System, 1990–2024"
doc = f'''<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/>
<title>{htmlmod.escape(title)}</title>
<style>
@page {{ size: A4; margin: 2.2cm 2cm; }}
body {{ font-family: "Times New Roman", Georgia, serif; font-size: 12pt; line-height: 2.0; color:#111; max-width:100%; }}
h1.title {{ font-size: 18pt; text-align:center; font-weight:bold; margin-bottom:18pt; }}
h2 {{ font-size: 13.5pt; font-weight:bold; margin-top:18pt; margin-bottom:8pt; border-bottom:0.5pt solid #888; padding-bottom:3pt;}}
h3 {{ font-size: 12pt; font-weight:bold; margin-top:13pt; margin-bottom:5pt;}}
h4 {{ font-size: 11pt; font-weight:bold; margin-top:10pt;}}
p {{ margin: 6pt 0; text-align:justify; }}
table {{ border-collapse: collapse; width:100%; margin:10pt 0; font-size: 9.3pt; }}
th,td {{ border: 0.5pt solid #777; padding: 4pt 6pt; text-align:left; }}
th {{ font-weight:bold; }}
.figure {{ text-align:center; margin:12pt 0; }}
.figure img {{ max-width:100%; height:auto; }}
code {{ font-family: Consolas, monospace; font-size: 10pt; }}
strong {{ font-weight:bold; }}
</style></head>
<body>
<h1 class="title">{htmlmod.escape(title)}</h1>
{body}
</body></html>'''

open(DST, 'w', encoding='utf-8').write(doc)
print('合并 HTML 已生成', DST)
print('表格总数:', body.count('<table>'), '（正文11 + 附录4 = 15）')
print('图片数:', body.count('class="figure"'))
print('附录表号:', [t for t in ['Table A1','Table A2','Table A3','Table A4'] if t in body])
print('未命中图片锚点:', miss if miss else '无')
