# -*- coding: utf-8 -*-
"""用 Pillow 直接绘制出版级 PNG 图（含坐标轴刻度、轴标签、图例、图题、2009参考线）。
不依赖 SVG->PNG 转换，从根本避免文字丢失。"""
import numpy as np, pandas as pd, os
from PIL import Image, ImageDraw, ImageFont

WD = 'D:/BaiduNetdiskDownload/年鉴分析/.workbuddy'
OUT = WD + '/results/figures_png'
os.makedirs(OUT, exist_ok=True)

FDIR = 'C:/Windows/Fonts/'
def font(sz, bold=False):
    name = 'arialbd.ttf' if bold else 'arial.ttf'
    return ImageFont.truetype(FDIR + name, sz)

C = dict(text=(30,30,30), grid=(224,226,229), axis=(70,70,70), muted=(110,115,120),
         red=(192,57,43), blue=(41,128,185), dark=(30,50,70),
         green=(39,174,96), orange=(230,126,34))

def new_canvas(W=1500,H=940, title=''):
    # 期刊惯例：图题只放在 caption 中，图片本体不写 "Figure N."
    im = Image.new('RGB',(W,H),'white'); d = ImageDraw.Draw(im)
    return im, d

def draw_axes(d, x0,y0,w,h, xmin,xmax,ymin,ymax, xticks,yticks, xlabel,ylabel,
              xtickfmt=int, yfmt='{:.2f}', fsize=24):
    fl = font(fsize); fa = font(fsize+2, True)
    # 网格 + y刻度
    for v in yticks:
        yy = y0+h-(v-ymin)/(ymax-ymin)*h
        d.line([(x0,yy),(x0+w,yy)], fill=C['grid'], width=2)
        lab = yfmt.format(v)
        bb = d.textbbox((0,0),lab,font=fl); d.text((x0-16-bb[2], yy-(bb[3]-bb[1])/2-2), lab, fill=C['muted'], font=fl)
    # x刻度
    for v in xticks:
        xx = x0+(v-xmin)/(xmax-xmin)*w
        d.line([(xx,y0+h),(xx,y0+h+12)], fill=C['axis'], width=2)
        lab = str(xtickfmt(v))
        bb = d.textbbox((0,0),lab,font=fl); d.text((xx-bb[2]/2, y0+h+16), lab, fill=C['muted'], font=fl)
    # 轴线
    d.line([(x0,y0),(x0,y0+h)], fill=C['axis'], width=3)
    d.line([(x0,y0+h),(x0+w,y0+h)], fill=C['axis'], width=3)
    # 轴标签
    bb=d.textbbox((0,0),xlabel,font=fa); d.text((x0+w/2-bb[2]/2, y0+h+58), xlabel, fill=C['text'], font=fa)
    # y轴竖排标签
    labim = Image.new('RGBA',(600,60),(255,255,255,0)); ld=ImageDraw.Draw(labim)
    ld.text((0,0),ylabel,fill=C['text'],font=fa)
    labim = labim.rotate(90,expand=True)
    # 贴到画布（需 im），这里返回给调用方
    return labim

def place(d, im, labim, x0, y0, h):
    # 竖排 y 轴标签贴在 x0-150 处（宽约 60px，占 x0-150..x0-90），
    # 与 y 刻度标签（右端 x0-16、左端约 x0-64）留出足够的水平间隙，避免遮挡首位数字
    im.paste(labim, (x0-150, int(y0+h/2-labim.height/2)), labim)

def polyline(d, xs, ys, x0,y0,w,h, xmin,xmax,ymin,ymax, color, width=5, dash=None):
    pts=[]
    vx=[]
    for x,y in zip(xs,ys):
        if y is None or (isinstance(y,float) and np.isnan(y)): continue
        xx=x0+(x-xmin)/(xmax-xmin)*w
        yy=y0+h-(y-ymin)/(ymax-ymin)*h
        pts.append((xx,yy))
    for i in range(len(pts)-1):
        if dash:
            seg = dash(pts[i],pts[i+1])
            for a,b in seg: d.line([a,b],fill=color,width=width)
        else:
            d.line([pts[i],pts[i+1]],fill=color,width=width)
    return pts

def dashed_segments(a,b,on=14,off=10):
    x1,y1=a; x2,y2=b; dx=x2-x1; dy=y2-y1; L=(dx*dx+dy*dy)**0.5
    if L==0: return []
    segs=[]; t=0.0
    while t<L:
        t2=min(t+on,L)
        segs.append(((x1+dx*t/L,y1+dy*t/L),(x1+dx*t2/L,y1+dy*t2/L)))
        t+=on+off
    return segs

# ================= 数据 =================
gini = pd.read_csv(WD+'/results/table1_gini_series.csv')
div  = pd.read_csv(WD+'/results/table3_divergence.csv')
kde  = pd.read_csv(WD+'/results/table4_kde.csv')
dag  = pd.read_csv(WD+'/results/table2_dagum.csv')

# ================= 图1：基尼趋势 =================
def fig1():
    im,d = new_canvas(title='Figure 1. Gini coefficients of health resources, 1990-2024')
    x0,y0,w,h = 230,120,1100,660
    labim = draw_axes(d,x0,y0,w,h,1990,2024,0.05,0.40,
        [1990,1995,2000,2005,2010,2015,2020,2024],[0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40],
        'Year','Gini coefficient',yfmt='{:.2f}')
    place(d,im,labim,x0,y0,h)
    phys=gini[gini['指标']=='医师密度']; fin=gini[gini['指标']=='财政卫生支出']
    polyline(d,phys['年份'],phys['基尼系数'],x0,y0,w,h,1990,2024,0.05,0.40,C['red'],6)
    polyline(d,fin['年份'],fin['基尼系数'],x0,y0,w,h,1990,2024,0.05,0.40,C['blue'],6)
    # 2009参考线
    x09=x0+(2009-1990)/(2024-1990)*w
    for a,b in dashed_segments((x09,y0),(x09,y0+h)): d.line([a,b],fill=C['muted'],width=3)
    d.text((x09+10,y0+10),'2009 reform',fill=C['muted'],font=font(22))
    # 图例
    lx,ly=880,160
    d.line([(lx,ly),(lx+50,ly)],fill=C['red'],width=6); d.text((lx+64,ly-14),'Physician density',fill=C['text'],font=font(24))
    d.line([(lx,ly+40),(lx+50,ly+40)],fill=C['blue'],width=6); d.text((lx+64,ly+26),'Fiscal health spending',fill=C['text'],font=font(24))
    im.save(OUT+'/fig1_gini_trend.png'); return im.size

# ================= 图2：背离指数 =================
def fig2():
    im,d = new_canvas(title='Fiscal-workforce decoupling index, 2001-2024')
    x0,y0,w,h = 230,120,1100,660
    xmin,xmax = 2001,2024
    labim = draw_axes(d,x0,y0,w,h,xmin,xmax,0.0,0.28,
        [2001,2005,2009,2013,2017,2021,2024],[0.0,0.05,0.10,0.15,0.20,0.25],
        'Year','Gini(fiscal) - Gini(physician)',yfmt='{:.2f}')
    place(d,im,labim,x0,y0,h)
    # 分两段：2001-2004 旧财政口径(浅灰虚线)，2008-2024 新口径(红色实线)
    old = div[div['年份']<=2004]; new = div[div['年份']>=2008]
    for sub,fillcol in [(old,(219,219,219)),(new,(235,205,200))]:
        poly=[(x0+(r['年份']-xmin)/(xmax-xmin)*w, y0+h-(r['背离指数'])/0.28*h)
              for _,r in sub.iterrows()]
        if len(poly)>=2:
            d.polygon([(poly[0][0],y0+h)]+poly+[(poly[-1][0],y0+h)],fill=fillcol)
    polyline(d,old['年份'],old['背离指数'],x0,y0,w,h,xmin,xmax,0,0.28,(150,150,150),5,dash=dashed_segments)
    polyline(d,new['年份'],new['背离指数'],x0,y0,w,h,xmin,xmax,0,0.28,C['red'],6)
    # 逐年数据点
    for _,r in div.iterrows():
        xx=x0+(r['年份']-xmin)/(xmax-xmin)*w; yy=y0+h-(r['背离指数'])/0.28*h
        col=(120,120,120) if r['年份']<=2004 else C['red']
        d.ellipse([xx-5,yy-5,xx+5,yy+5],fill=col)
    # 2007 财政口径断点（灰色，标签置底部，仅画下半段）
    x07=x0+(2007-xmin)/(xmax-xmin)*w
    for a,b in dashed_segments((x07,y0+h/2),(x07,y0+h)): d.line([a,b],fill=C['muted'],width=3)
    d.text((x07-118,y0+h-52),'2007 fiscal break',fill=C['muted'],font=font(20))
    # 2009 医改参考线（橙色，全程，标签置顶部）
    x09=x0+(2009-xmin)/(xmax-xmin)*w
    for a,b in dashed_segments((x09,y0),(x09,y0+h)): d.line([a,b],fill=C['orange'],width=3)
    d.text((x09+12,y0+58),'2009 reform',fill=C['orange'],font=font(22))
    # 峰值标注（新口径段）
    pk=new.loc[new['背离指数'].idxmax()]
    px=x0+(pk['年份']-xmin)/(xmax-xmin)*w; py=y0+h-(pk['背离指数'])/0.28*h
    d.ellipse([px-9,py-9,px+9,py+9],fill=C['red'])
    d.text((px-230,py-46),f'Peak {pk["背离指数"]:.3f} ({int(pk["年份"])})',fill=C['red'],font=font(24))
    # 改革后趋势线（2009-2024，同口径）
    post=new[new['年份']>=2009]
    xs=post['年份'].values.astype(float); ys=post['背离指数'].values
    coef=np.polyfit(xs-2009,ys,1)
    polyline(d,xs,coef[0]*(xs-2009)+coef[1],x0,y0,w,h,xmin,xmax,0,0.28,C['dark'],4,dash=dashed_segments)
    d.text((x0+24,y0+8),f'Post-2009 trend: +{coef[0]:.4f}/yr (HAC t=5.53)',fill=C['dark'],font=font(23))
    # 图例：两段口径
    d.line([(x0+30,y0+h-150),(x0+80,y0+h-150)],fill=(150,150,150),width=5)
    d.text((x0+92,y0+h-163),'2001-2004: old fiscal caliber',fill=C['muted'],font=font(20))
    d.line([(x0+30,y0+h-116),(x0+80,y0+h-116)],fill=C['red'],width=5)
    d.text((x0+92,y0+h-129),'2008-2024: new fiscal caliber',fill=C['muted'],font=font(20))
    im.save(OUT+'/fig2_divergence.png'); return im.size

# ================= 图3：核密度 =================
def fig3():
    im,d = new_canvas(title='Figure 3. Distribution dynamics of physician density')
    x0,y0,w,h = 230,120,1100,660
    labim = draw_axes(d,x0,y0,w,h,0,45,0,0.16,[0,10,20,30,40],[0,0.04,0.08,0.12,0.16],
        'Physicians per 10,000 population','Kernel density',yfmt='{:.2f}')
    place(d,im,labim,x0,y0,h)
    colors={1990:(189,195,199),2009:C['orange'],2015:C['blue'],2024:C['red']}
    for y in [1990,2009,2015,2024]:
        sub=kde[kde['年份']==y]
        if len(sub)==0: continue
        polyline(d,sub['医师密度'],sub['密度'],x0,y0,w,h,0,45,0,0.16,colors[y],6)
    lx,ly=1120,170
    for i,(y,c) in enumerate(colors.items()):
        yy=ly+i*44
        d.line([(lx,yy),(lx+46,yy)],fill=c,width=6)
        d.text((lx+60,yy-15),str(y),fill=C['text'],font=font(24))
    im.save(OUT+'/fig3_kde.png'); return im.size

# ================= 图4：Dagum堆叠柱 =================
def fig4():
    im,d = new_canvas(title='Figure 4. Dagum decomposition of physician-density inequality')
    x0,y0,w,h = 230,120,1100,660
    # y轴 0-1
    for v in [0,0.2,0.4,0.6,0.8,1.0]:
        yy=y0+h-v*h
        d.line([(x0,yy),(x0+w,yy)],fill=C['grid'],width=2)
        lab=f'{v:.1f}'; bb=d.textbbox((0,0),lab,font=font(24))
        d.text((x0-16-bb[2],yy-14),lab,fill=C['muted'],font=font(24))
    d.line([(x0,y0),(x0,y0+h)],fill=C['axis'],width=3)
    d.line([(x0,y0+h),(x0+w,y0+h)],fill=C['axis'],width=3)
    bb=d.textbbox((0,0),'Year',font=font(26)); d.text((x0+w/2-bb[2]/2,y0+h+58),'Year',fill=C['text'],font=font(26))
    labim=Image.new('RGBA',(600,60),(255,255,255,0)); ld=ImageDraw.Draw(labim)
    ld.text((0,0),'Share of Gini',fill=C['text'],font=font(26))
    labim=labim.rotate(90,expand=True); place(d,im,labim,x0,y0,h)
    years=[1990,2009,2015,2020,2024]
    cols=[('组内贡献',C['green']),('组间贡献',C['blue']),('超变密度贡献',C['red'])]
    # 1990从补算值补入
    data={1990:(0.275,0.211,0.514)}
    for _,r in dag[(dag['指标']=='医师密度')].iterrows():
        data[int(r['年份'])]=(r['组内贡献'],r['组间贡献'],r['超变密度贡献'])
    bw=120; gap=(w-len(years)*bw)/(len(years)+1)
    for i,y in enumerate(years):
        cx=x0+gap+i*(bw+gap)
        base=y0+h
        vals=data[y]
        for (_,col),val in zip(cols,vals):
            hh=val*h
            d.rectangle([cx,base-hh,cx+bw,base],fill=col)
            # 段内百分比
            if val>0.08:
                lab=f'{val*100:.0f}%'; f=font(22,True); bb=d.textbbox((0,0),lab,font=f)
                d.text((cx+bw/2-bb[2]/2,base-hh/2-12),lab,fill='white',font=f)
            base-=hh
        bb=d.textbbox((0,0),str(y),font=font(24)); d.text((cx+bw/2-bb[2]/2,y0+h+16),str(y),fill=C['muted'],font=font(24))
    # 图例：放在绘图区上方、图题下方的一行，避开柱子与百分比
    lx,ly=520,86
    for i,(key,col) in enumerate([('Within-region',C['green']),('Between-region',C['blue']),('Transvariation',C['red'])]):
        xx=lx+i*320
        d.rectangle([xx,ly,xx+24,ly+24],fill=col)
        d.text((xx+34,ly-2),key,fill=C['text'],font=font(23))
    im.save(OUT+'/fig4_dagum.png'); return im.size

# ================= 图5：连续DID事件研究 =================
def fig5():
    ev = pd.read_csv(WD+'/results/robustness/event_study_continuous.csv')
    im,d = new_canvas()
    x0,y0,w,h = 230,110,1100,660
    ymin,ymax = -0.30,0.30
    labim = draw_axes(d,x0,y0,w,h,1999,2025,ymin,ymax,
        [2000,2004,2008,2012,2016,2020,2024],[-0.30,-0.20,-0.10,0.0,0.10,0.20,0.30],
        'Year','Effect per SD of baseline physician density',yfmt='{:.2f}')
    place(d,im,labim,x0,y0,h)
    # 零线
    yz=y0+h-(0-ymin)/(ymax-ymin)*h
    d.line([(x0,yz),(x0+w,yz)],fill=C['axis'],width=3)
    # 2009 改革线
    x09=x0+(2009-1999)/(2025-1999)*w
    for a,b in dashed_segments((x09,y0),(x09,y0+h)): d.line([a,b],fill=C['muted'],width=3)
    d.text((x09+10,y0+70),'2009 reform',fill=C['muted'],font=font(22))
    # 置信区间与点估计
    for _,r in ev.iterrows():
        xx=x0+(r['年份']-1999)/(2025-1999)*w
        yb=y0+h-(min(r['hi'],ymax)-ymin)/(ymax-ymin)*h
        yt=y0+h-(max(r['lo'],ymin)-ymin)/(ymax-ymin)*h
        d.line([(xx,yb),(xx,yt)],fill=C['blue'],width=3)
        yp=y0+h-(r['beta']-ymin)/(ymax-ymin)*h
        col=C['muted'] if r['年份']<2009 else C['red']
        d.ellipse([xx-7,yp-7,xx+7,yp+7],fill=col)
    d.text((x0+24,y0+16),'Grey = pre-reform, red = post-reform; bars = 95% CI (province-clustered)',
           fill=C['dark'],font=font(22))
    im.save(OUT+'/fig5_event_study.png'); return im.size

for f in [fig1,fig2,fig3,fig4,fig5]:
    print(f.__name__,f())
print('输出目录',OUT,os.listdir(OUT))
