# -*- coding: utf-8 -*-
"""主计量分析：财政—人力背离 (Fiscal-Workforce Decoupling) 全套实证"""
import numpy as np, pandas as pd, json, os
from econo_utils import gini, dagum_decompose, kde, spatial_weights, morans_i, markov_transition, OLS, ols_cluster

WD = 'D:/BaiduNetdiskDownload/年鉴分析/.workbuddy'
OUT = WD + '/results'
os.makedirs(OUT, exist_ok=True)
m = pd.read_csv(WD + '/master_panel.csv')

regions = {'东部':['北京','天津','河北','上海','江苏','浙江','福建','山东','广东','海南'],
           '中部':['山西','安徽','江西','河南','湖北','湖南'],
           '西部':['内蒙古','广西','重庆','四川','贵州','云南','西藏','陕西','甘肃','青海','宁夏','新疆'],
           '东北':['辽宁','吉林','黑龙江']}
r2g = {r:g for g,rs in regions.items() for r in rs}
m['region'] = m['prov'].map(r2g)

results = {}  # 汇总所有结果表

# ============================================================
# 1. 基尼系数长时序 + Dagum分解（医师、财政、床位、护士）
# ============================================================
print('=== 1. 基尼系数与Dagum分解 ===')
gine_rows=[]
for col,label,ymin in [('每万人拥有执业(助理)医师数(人)','医师密度',1990),
                        ('财政卫生支出亿元','财政卫生支出',2000),
                        ('每万人医疗机构床位数(张)','床位密度',2008),
                        ('每万人拥有注册护士数(人)','护士密度',2008)]:
    for y in range(ymin, 2025):
        d=m[m['年份']==y][['prov',col]].dropna()
        d=d[d['prov'].isin(r2g)]
        if len(d)>=25:
            gine_rows.append({'指标':label,'年份':y,'基尼系数':gini(d[col].values),'省数':len(d)})
gine=pd.DataFrame(gine_rows)
gine.to_csv(OUT+'/table1_gini_series.csv',index=False,encoding='utf-8-sig')
results['gini_2024_医师']=float(gine[(gine['指标']=='医师密度')&(gine['年份']==2024)]['基尼系数'].iloc[0])
results['gini_1990_医师']=float(gine[(gine['指标']=='医师密度')&(gine['年份']==1990)]['基尼系数'].iloc[0])

# Dagum分解：关键年份 医师 & 财政
dagum_rows=[]
for col,label in [('每万人拥有执业(助理)医师数(人)','医师密度'),('财政卫生支出亿元','财政卫生支出')]:
    for y in [2000,2009,2015,2020,2024]:
        d=m[m['年份']==y][['prov',col]].dropna(); d=d[d['prov'].isin(r2g)]
        if len(d)<25: continue
        d['g']=d['prov'].map(r2g)
        r=dagum_decompose(d[col].values,d['g'].values)
        dagum_rows.append({'指标':label,'年份':y,'G':r['G'],'组内贡献':r['Gw_share'],
                           '组间贡献':r['Gb_share'],'超变密度贡献':r['Gt_share']})
dagum=pd.DataFrame(dagum_rows)
dagum.to_csv(OUT+'/table2_dagum.csv',index=False,encoding='utf-8-sig')
print(dagum.to_string(index=False))

# ============================================================
# 2. 投入—产出背离指数
# ============================================================
print('\n=== 2. 投入—产出背离指数 ===')
div_rows=[]
for y in range(2000,2025):  # 2001-2004 医师与财政序列均完整，纳入以扩展改革前区间
    a=m[m['年份']==y]['每万人拥有执业(助理)医师数(人)'].dropna()
    b=m[m['年份']==y]['财政卫生支出亿元'].dropna()
    if len(a)>=28 and len(b)>=28:
        ga,gb=gini(a.values),gini(b.values)
        div_rows.append({'年份':y,'医师基尼':ga,'财政基尼':gb,'背离指数':gb-ga})
div=pd.DataFrame(div_rows)
div.to_csv(OUT+'/table3_divergence.csv',index=False,encoding='utf-8-sig')
results['背离_2009']=float(div[div['年份']==2009]['背离指数'].iloc[0])
results['背离_2022峰值']=float(div[div['年份']==2022]['背离指数'].iloc[0])
results['背离_2024']=float(div[div['年份']==2024]['背离指数'].iloc[0])
print(div.to_string(index=False))

# ============================================================
# 3. 核密度估计（医师密度分布演进）
# ============================================================
print('\n=== 3. 核密度估计 ===')
kde_rows=[]
grid=np.linspace(0,50,300)
for y in [1990,2009,2015,2020,2024]:
    x=m[m['年份']==y]['每万人拥有执业(助理)医师数(人)'].dropna().values
    if len(x)<5: continue
    g,dens,bw=kde(x,grid=grid)
    kde_rows.append(pd.DataFrame({'年份':y,'医师密度':g,'密度':dens,'带宽':bw}))
kde_df=pd.concat(kde_rows,ignore_index=True)
kde_df.to_csv(OUT+'/table4_kde.csv',index=False,encoding='utf-8-sig')
# 峰值位置
for y in [1990,2009,2024]:
    sub=kde_df[kde_df['年份']==y]
    if len(sub)==0: continue
    print(f'  医师密度KDE {y}: 峰值={sub.loc[sub["密度"].idxmax(),"医师密度"]:.2f}, 带宽={sub["带宽"].iloc[0]:.3f}')

# ============================================================
# 4. 空间自相关 Moran's I
# ============================================================
print('\n=== 4. 空间自相关 ===')
coords=pd.read_csv(WD+'/prov_coords.csv').set_index('地区')
W,_=spatial_weights(coords,kind='inv_dist')
moran_rows=[]
for col,label in [('每万人拥有执业(助理)医师数(人)','医师密度'),('财政卫生支出亿元','财政卫生支出')]:
    for y in [2000,2009,2015,2020,2024]:
        s=m[m['年份']==y].set_index('prov')[col].dropna()
        s=s.reindex(W.index).dropna()
        I,EI,zI,pval=morans_i(s,W)
        moran_rows.append({'指标':label,'年份':y,'Moran I':I,'期望':EI,'Z值':zI,'p值':pval})
moran=pd.DataFrame(moran_rows)
moran.to_csv(OUT+'/table5_moran.csv',index=False,encoding='utf-8-sig')
print(moran.to_string(index=False))
results['moran_医师_2024']=float(moran[(moran['指标']=='医师密度')&(moran['年份']==2024)]['Moran I'].iloc[0])

# ============================================================
# 5. β-收敛回归（绝对+条件）+ 空间滞后模型(SDM近似)
# ============================================================
print('\n=== 5. β收敛回归 ===')
# 构造增长面板：2000-2024，每省期初对期末（分两个子期）
def beta_sample(df,col,y0,y1):
    a=df[df['年份']==y0].set_index('prov')[col]
    b=df[df['年份']==y1].set_index('prov')[col]
    common=a.index.intersection(b.index)
    g=np.log(b[common]/a[common])  # 增长
    init=np.log(a[common])
    return pd.DataFrame({'prov':common,'增长':g,'期初对数':init}).dropna()

conver_rows=[]
for col,label in [('每万人拥有执业(助理)医师数(人)','医师密度'),('财政卫生支出亿元','财政卫生支出')]:
    periods = [(1990,2024),(2009,2024)] if '医师' in label else [(2000,2024),(2009,2024)]
    for y0,y1 in periods:
        s=beta_sample(m,col,y0,y1)
        if len(s)<20: continue
        mod,names,d=ols_cluster(s,'增长',['期初对数'],cluster='prov')
        conv=-mod.beta[1]/(y1-y0)
        half=np.log(2)/conv if conv>0 else np.nan
        conver_rows.append({'指标':label,'时期':f'{y0}-{y1}','β系数':mod.beta[1],'t值':mod.t[1],
                            '收敛速度':conv,'半程年':half,'N':len(d),'R2':mod.r2})
conver=pd.DataFrame(conver_rows)
conver.to_csv(OUT+'/table6_beta_convergence.csv',index=False,encoding='utf-8-sig')
print(conver.to_string(index=False))

# ============================================================
# 6. 空间杜宾模型 SDM: 医师密度增长的空间收敛
# ============================================================
print('\n=== 6. 空间收敛(SDM) ===')
s=beta_sample(m,'每万人拥有执业(助理)医师数(人)',2009,2024)
s=s.set_index('prov')
Wm=W.loc[s.index,s.index]
# 空间滞后因变量 W*y 与空间滞后自变量 W*x
s['W_增长']=Wm.values @ s['增长'].values
s['W_期初']=Wm.values @ s['期初对数'].values
s=s.reset_index()
mod,names,d=ols_cluster(s,'增长',['期初对数','W_期初','W_增长'],cluster='prov')
sdm_rows=[]
for nm,b,se,t in zip(names,mod.beta,mod.se,mod.t):
    sdm_rows.append({'变量':nm,'系数':b,'标准误':se,'t值':t})
sdm=pd.DataFrame(sdm_rows)
sdm.to_csv(OUT+'/table7_sdm.csv',index=False,encoding='utf-8-sig')
print(sdm.to_string(index=False))
print(f'  空间自回归 rho(W_增长)={mod.beta[names.index("W_增长")]:.4f}')
results['sdm_rho']=float(mod.beta[names.index('W_增长')])

# ============================================================
# 7. 马尔可夫链（医师密度等级转移）
# ============================================================
print('\n=== 7. 马尔可夫链 ===')
# 用分位数把医师密度分4级
piv=m.pivot(index='prov',columns='年份',values='每万人拥有执业(助理)医师数(人)')
bins=np.nanpercentile(piv.values,[25,50,75])
def state(v):
    if np.isnan(v): return None
    return 1 if v<bins[0] else (2 if v<bins[1] else (3 if v<bins[2] else 4))
states={}
for prov in piv.index:
    seq=[(int(y),state(piv.loc[prov,y])) for y in piv.columns if not np.isnan(piv.loc[prov,y])]
    states[prov]=[(y,s) for y,s in seq if s is not None]
P,counts=markov_transition(states,4)
Pdf=pd.DataFrame(P,index=[f'{i}→' for i in range(1,5)],columns=[f'状态{j}' for j in range(1,5)])
Pdf.to_csv(OUT+'/table8_markov.csv',encoding='utf-8-sig')
print('  医师密度马尔可夫转移矩阵(4状态):')
print(Pdf.round(3).to_string())
# 对角线概率(维持原级)
diag=np.diag(P)
results['markov_diag']=diag.tolist()

# ============================================================
# 8. 2009新医改 DID / 事件研究（对财政投入与人力配置）
# ============================================================
print('\n=== 8. 新医改DID ===')
# 处理组：2009年前医师密度低于中位数的省（改革重点倾斜地区）
pre=m[m['年份']==2008].set_index('prov')['每万人拥有执业(助理)医师数(人)']
med=pre.median()
treat=set(pre[pre<=med].index)
m['treat']=m['prov'].isin(treat).astype(int)
m['post']=(m['年份']>=2009).astype(int)
m['did']=m['treat']*m['post']
# 结果变量：人均财政卫生支出(log)、医师密度(log)
for ycol in ['人均财政卫生支出','每万人拥有执业(助理)医师数(人)']:
    d=m[m['年份'].between(2000,2024)].dropna(subset=[ycol]).copy()
    d['y']=np.log(d[ycol])
    mod,names,dd=ols_cluster(d,'y',['treat','post','did','地区生产总值(亿元)'],cluster='prov',add_fe=['prov','年份'])
    didbeta=mod.beta[names.index('did')]; didt=mod.t[names.index('did')]
    print(f'  {ycol}: DID={didbeta:.4f}, t={didt:.2f}')
    results['did_'+ycol]={'beta':float(didbeta),'t':float(didt)}
# 事件研究：逐年 treat 效应
event_rows=[]
d=m[m['年份'].between(2000,2024)].dropna(subset=['人均财政卫生支出']).copy()
d['y']=np.log(d['人均财政卫生支出'])
for yr in [2004,2006,2008,2010,2012,2015,2018,2021,2024]:
    d['treat_yr']=(d['treat']*(d['年份']==yr)).astype(int)
    mod,names,dd=ols_cluster(d,'y',['treat_yr','年份','地区生产总值(亿元)'],cluster='prov',add_fe=['prov'])
    event_rows.append({'年份':yr,'效应':mod.beta[names.index('treat_yr')],'t值':mod.t[names.index('treat_yr')]})
ev=pd.DataFrame(event_rows)
ev.to_csv(OUT+'/table9_event_study.csv',index=False,encoding='utf-8-sig')
print('  事件研究(人均财政卫生支出):')
print(ev.to_string(index=False))

# ============================================================
# 9. 机制回归：财政投入 → 人力配置（省级面板FE）
# ============================================================
print('\n=== 9. 机制回归 财政→人力 ===')
d=m[m['年份'].between(2000,2024)].dropna(subset=['执业医师每千人','人均财政卫生支出']).copy()
d['y']=np.log(d['执业医师每千人'])
d['lnfiscal']=np.log(d['人均财政卫生支出'])
mod,names,dd=ols_cluster(d,'y',['lnfiscal','老年人口抚养比(人口抽样调查)(%)','地区生产总值(亿元)'],cluster='prov',add_fe=['prov','年份'])
mech=pd.DataFrame({'变量':names,'系数':mod.beta,'标准误':mod.se,'t值':mod.t})
mech.to_csv(OUT+'/table10_mechanism.csv',index=False,encoding='utf-8-sig')
print(mech.to_string(index=False))
results['mech_财政系数']=float(mod.beta[names.index('lnfiscal')])

# ============================================================
# 保存所有结果摘要JSON
# ============================================================
with open(OUT+'/results_summary.json','w',encoding='utf-8') as f:
    json.dump(results,f,ensure_ascii=False,indent=2)
print('\n=== 全部结果已保存到',OUT,'===')
print(json.dumps(results,ensure_ascii=False,indent=2))
