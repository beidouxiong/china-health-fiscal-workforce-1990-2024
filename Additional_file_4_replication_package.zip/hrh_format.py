# -*- coding: utf-8 -*-
"""HRH 投稿格式后处理：注入行号、页脚页码、全文双倍行距、A4 页边距。
输入：转换生成的原始 DOCX（原地修改）。"""
import sys, copy
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_LINE_SPACING, WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

def set_line_numbering(section, count_by=1, start=1, restart='newPage'):
    sectPr = section._sectPr
    # 移除已有 lnNumType
    for el in sectPr.findall(qn('w:lnNumType')):
        sectPr.remove(el)
    ln = OxmlElement('w:lnNumType')
    ln.set(qn('w:countBy'), str(count_by))
    ln.set(qn('w:start'), str(start))
    ln.set(qn('w:restart'), restart)
    sectPr.append(ln)

def add_page_number_footer(section):
    footer = section.footer
    p = footer.paragraphs[0] if footer.paragraphs else footer.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for r in list(p.runs):
        r._element.getparent().remove(r._element)
    run = p.add_run()
    fld1 = OxmlElement('w:fldChar'); fld1.set(qn('w:fldCharType'), 'begin')
    instr = OxmlElement('w:instrText'); instr.set(qn('xml:space'), 'preserve'); instr.text = ' PAGE '
    fld2 = OxmlElement('w:fldChar'); fld2.set(qn('w:fldCharType'), 'end')
    run._r.append(fld1); run._r.append(instr); run._r.append(fld2)
    for r in p.runs:
        r.font.size = Pt(10)

def force_double_spacing(doc):
    def fix(paragraph):
        pf = paragraph.paragraph_format
        pf.line_spacing_rule = WD_LINE_SPACING.DOUBLE
        pf.space_before = Pt(0)
        pf.space_after = Pt(0)
    for p in doc.paragraphs:
        fix(p)
    for t in doc.tables:
        for row in t.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    fix(p)
    for sec in doc.sections:
        for p in sec.footer.paragraphs:
            for r in p.runs:
                r.font.size = Pt(10)

def process(path):
    doc = Document(path)
    for sec in doc.sections:
        sec.page_height = Cm(29.7); sec.page_width = Cm(21.0)
        sec.top_margin = Cm(2.2); sec.bottom_margin = Cm(2.2)
        sec.left_margin = Cm(2.0); sec.right_margin = Cm(2.0)
        set_line_numbering(sec)
        add_page_number_footer(sec)
    force_double_spacing(doc)
    doc.save(path)
    print('已注入 HRH 格式:', path)
    print('  段落数:', len(doc.paragraphs), '表格数:', len(doc.tables), '节数:', len(doc.sections))

if __name__ == '__main__':
    for p in sys.argv[1:]:
        process(p)
