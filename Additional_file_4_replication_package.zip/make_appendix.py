# -*- coding: utf-8 -*-
"""生成 Online Appendix：Q1 口径诊断的全规格 ITS 表、扩展序列、留一法敏感性。
数据来源 results/q1/q1_results.json 与 results/q1/divergence_extended.csv。"""
import json, pandas as pd, os

WD = 'D:/BaiduNetdiskDownload/年鉴分析/.workbuddy'
r = json.load(open(WD + '/results/q1/q1_results.json', encoding='utf-8'))
ext = pd.read_csv(WD + '/results/q1/divergence_extended.csv')

L = []
A = L.append
A('## Online Appendix')
A('')
A('**Convergence Without Equalization: Fiscal–Workforce Decoupling in China\'s Health System, 1990–2024**')
A('')
A('This appendix documents the fiscal-caliber identification diagnosis summarized in Section 4.7. '
  'All quantities are recomputed from the harmonized six-yearbook province panel and are fully '
  'reproducible from `q1_analysis.py` and `results/q1/q1_results.json`.')
A('')

# ---- Table A1: extended series ----
A('## Table A1. Extended fiscal–workforce decoupling index, 2001–2024')
A('')
A('D_t = Gini(fiscal health spending) − Gini(physician density). Caliber 0 = old (2000–2006); '
  'Caliber 1 = new (2007 onward). No physician observations exist for 2000 or 2005–2007, '
  'so the series has 21 observed years.')
A('')
A('| Year | Physician Gini | Fiscal Gini | D_t | Fiscal caliber |')
A('|---|---|---|---|---|')
for _, row in ext.iterrows():
    A(f'| {int(row["年份"])} | {row["医师基尼"]:.4f} | {row["财政基尼"]:.4f} | '
      f'{row["背离指数"]:.4f} | {int(row["口径"])} |')
A('')

# ---- Table A2: ITS specifications ----
A('## Table A2. Interrupted time-series specifications for the decoupling index')
A('')
A('Newey–West HAC standard errors (lag 2). t = years since 2009; Post = 1(year≥2009); '
  'Caliber = 1(year≥2007); Caliber×t is the caliber-specific slope. '
  '**None of these specifications is interpreted causally** — see Section 4.7.')
A('')
A('| Spec | Constant | t | Post | Post×t | Caliber | Caliber×t | N |')
A('|---|---|---|---|---|---|---|---|')
specs = [
    ('A. No caliber control', 'its_A_no_accounting_2001_2024'),
    ('B. + caliber dummy', 'its_B_with_accounting_dummy'),
    ('C. + caliber level & slope', 'its_C_accounting_level_and_slope'),
    ('D. Exclude 2008', 'its_D_exclude_2008'),
    ('E. New caliber only (2008–24)', 'its_E_new_accounting_only'),
]
order = ['1', 't', 'post', 'post_t', 'acct', 'acct_t']
def fmt(d, key):
    if key not in d['coef']:
        return '—'
    c = d['coef'][key]
    sig = '*' if c['p'] < 0.05 else ''
    return f'{c["b"]:+.4f}{sig}<br>({c["t"]:+.2f})'
for label, key in specs:
    d = r[key]
    cells = [fmt(d, k) for k in order]
    A(f'| {label} | ' + ' | '.join(cells) + f' | {d["n"]} |')
A('')
A('*Note:* * p<0.05. Cells show coefficient with HAC t-statistic in parentheses. '
  'Specification D is degenerate: with 2008 removed, the caliber and reform dummies are '
  'exactly collinear (both switch in the single year 2008→2009), so their coefficients are '
  'not separately identified — the identical estimate shown for Post and Caliber is an '
  'artifact of the pseudo-inverse. This is precisely why a segmented reform-effect estimate '
  'is not reported in the main text.')
A('')

# ---- Table A3: pre-trend sensitivity ----
A('## Table A3. Pre-reform slope sensitivity')
A('')
A('The "clean" old-caliber pre-reform window contains only four years (2001–2004). '
  'Leave-one-out slopes and the slope including the single new-caliber pre-reform point (2008) '
  'show that the sign of the pre-reform trend is not robust.')
A('')
A('| Sample | Slope (per year) | HAC t | N |')
A('|---|---|---|---|')
pt = r['pre_trend_2001_2004_only']
A(f'| 2001–2004 (all four old-caliber years) | {pt["slope"]:+.4f} | {pt["t"]:+.2f} | {pt["n"]} |')
for v in r['pre_trend_loo']:
    A(f'| 2001–2004 excluding {v["dropped"]} | {v["slope"]:+.4f} | {v["t"]:+.2f} | 3 |')
pw = r['pre_trend_with_2008']
A(f'| 2001–2008 including 2008 (new caliber) | {pw["slope"]:+.4f} | {pw["t"]:+.2f} | {pw["n"]} |')
A('')

# ---- Table A4: identification diagnostics ----
A('## Table A4. Caliber–reform identification diagnostics')
A('')
A('| Diagnostic | Value |')
A('|---|---|')
aj = r['accounting_jump']
A(f'| Fiscal Gini, 2006 (old caliber) | {aj["fiscal_gini_2006"]:.4f} |')
A(f'| Fiscal Gini, 2007 (new caliber) | {aj["fiscal_gini_2007"]:.4f} |')
A(f'| Level jump at caliber break | {aj["jump"]:+.4f} |')
idn = r['identification']
A(f'| Correlation, caliber dummy × reform dummy | {idn["corr_D07_D09"]:.3f} |')
A(f'| Pre-reform observations, old caliber | {idn["n_pre_old_accounting"]} (2001–2004) |')
A(f'| Pre-reform observations, new caliber | {idn["n_pre_new_accounting"]} (2008) |')
A(f'| Gap in physician data | 2004→2008 = {idn["gap_2004_to_2008"]} years |')
A('')
A('The 2007 level jump (−0.0368 in fiscal Gini) is of the same order as the entire '
  'pre-reform drift of the index, and because the jump year has no physician observation, '
  'its level effect must be identified from 2008 alone. With the caliber and reform dummies '
  'correlated at 0.87, a segmented slope comparison cannot separate a reform effect from a '
  'reporting change. The main text therefore reports only the within-caliber post-2009 trend.')
A('')

md = '\n'.join(L)
out = WD + '/online_appendix_en.md'
open(out, 'w', encoding='utf-8').write(md)
print('Written', out, len(md), 'chars,', len(L), 'lines')
