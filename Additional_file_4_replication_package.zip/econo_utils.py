# -*- coding: utf-8 -*-
"""纯 numpy 计量工具箱：OLS/FE/聚类稳健SE + Gini/Dagum + KDE + Moran + Markov"""
import numpy as np
import pandas as pd

# ---------- OLS 与固定效应 ----------
class OLS:
    def __init__(self, X, y, cluster=None, fe_groups=None):
        X = np.asarray(X, float); y = np.asarray(y, float)
        self.n, self.k = X.shape
        XtX_inv = np.linalg.pinv(X.T @ X)
        beta = XtX_inv @ X.T @ y
        self.beta = beta
        resid = y - X @ beta
        self.resid = resid
        dof = self.n - np.linalg.matrix_rank(X)
        s2 = (resid @ resid) / dof
        if cluster is None:
            cov = s2 * XtX_inv
        else:
            cl = np.asarray(cluster)
            cov = np.zeros((self.k, self.k))
            for g in np.unique(cl):
                m = cl == g
                Xg = X[m]; eg = resid[m]
                s = Xg.T @ eg
                cov += np.outer(s, s)
            G = len(np.unique(cl))
            cov = XtX_inv @ cov @ XtX_inv
            cov *= (G / (G - 1)) * ((self.n - 1) / dof)
        self.cov = cov
        self.se = np.sqrt(np.diag(cov))
        self.t = beta / self.se
        try:
            from math import erf
            self.p = np.array([2 * (1 - 0.5 * (1 + erf(abs(t) / np.sqrt(2)))) for t in self.t])
        except Exception:
            self.p = np.full_like(self.t, np.nan)
        ss_tot = ((y - y.mean()) ** 2).sum()
        self.r2 = 1 - (resid @ resid) / ss_tot if ss_tot > 0 else np.nan

    def summary(self, names=None):
        names = names or [f'x{i}' for i in range(self.k)]
        out = []
        for i, nm in enumerate(names):
            stars = '***' if self.p[i] < 0.01 else ('**' if self.p[i] < 0.05 else ('*' if self.p[i] < 0.1 else ''))
            out.append(f'{nm:28s} {self.beta[i]:12.5f}  se={self.se[i]:9.5f}  t={self.t[i]:7.2f}{stars}')
        return '\n'.join(out)


def ols_cluster(df, ycol, xcols, cluster='prov', add_fe=None, robust=True):
    """便捷接口：从DataFrame估计OLS，支持省份聚类SE、省份/年份固定效应。"""
    d = df.dropna(subset=[ycol] + xcols).copy()
    Xcols = list(xcols); y = d[ycol].values.astype(float)
    blocks = [np.ones((len(d), 1))]
    names = ['const']
    for c in Xcols:
        blocks.append(d[[c]].values.astype(float)); names.append(c)
    if add_fe:
        for fe in add_fe:
            dums = pd.get_dummies(d[fe], prefix=fe, drop_first=True).values.astype(float)
            blocks.append(dums); names += [f'{fe}={v}' for v in pd.get_dummies(d[fe], drop_first=True).columns]
    X = np.hstack(blocks)
    cl = d[cluster].values if cluster else None
    m = OLS(X, y, cluster=cl if robust else None)
    return m, names, d

# ---------- 基尼与 Dagum 分解 ----------
def gini(x):
    x = np.sort(np.asarray(x, float)); n = len(x)
    if n == 0 or x.sum() == 0: return np.nan
    return (2 * np.arange(1, n + 1) - n - 1).dot(x) / (n * x.sum())

def dagum_decompose(x, grp):
    """精确分解 G = Gw + Gb(净组间) + Gt(超变密度/重叠)。grp 为分组标签。
    恒等式已校验：Gw + Gb + Gt == G。"""
    x = np.asarray(x, float); grp = np.asarray(grp); n = len(x); mu = x.mean()
    groups = np.unique(grp); k = len(groups)
    G = np.abs(x[:, None] - x[None, :]).sum() / (2 * n * n * mu)
    Gw = sum((x[grp == g].size / n) ** 2 * x[grp == g].mean() / mu * gini(x[grp == g])
             for g in groups)
    Gb = 0.0; Gt = 0.0
    for ii in range(k):
        for jj in range(ii + 1, k):
            a, b = groups[ii], groups[jj]
            xa, xb = x[grp == a], x[grp == b]
            na, nb = len(xa), len(xb)
            ma, mb = xa.mean(), xb.mean()
            Gb += na * nb * abs(ma - mb) / (n * n * mu)
            hi, lo = (xa, xb) if ma > mb else (xb, xa)
            overlap = np.maximum(lo[:, None] - hi[None, :], 0).sum()
            Gt += 2 * overlap / (n * n * mu)
    # 数值稳健：残差归入 Gb
    Gb = G - Gw - Gt
    return {'G': G, 'Gw': Gw, 'Gb': Gb, 'Gt': Gt,
            'Gw_share': Gw / G, 'Gb_share': Gb / G, 'Gt_share': Gt / G,
            'check': Gw + Gb + Gt}

# ---------- 核密度估计 ----------
def kde(x, grid=None, bw=None, ngrid=200):
    x = np.asarray(x, float); x = x[~np.isnan(x)]
    if bw is None:
        # Silverman 规则（稳健处理退化分布）
        q75, q25 = np.percentile(x, 75), np.percentile(x, 25)
        sd = np.nanstd(x)
        spread = min(sd if np.isfinite(sd) else np.inf, (q75 - q25) / 1.34)
        if not np.isfinite(spread) or spread <= 0:
            spread = 1.0
        bw = 0.9 * spread * len(x) ** (-0.2)
        bw = max(bw, 1e-3)
    if grid is None:
        grid = np.linspace(x.min() - bw, x.max() + bw, ngrid)
    z = (grid[:, None] - x[None, :]) / bw
    dens = np.exp(-0.5 * z ** 2).mean(axis=1) / (bw * np.sqrt(2 * np.pi))
    return grid, dens, bw

# ---------- 空间权重矩阵 ----------
def spatial_weights(coords, kind='inv_dist', threshold=None, k=None):
    """coords: DataFrame index=prov, columns=[lon,lat]。返回行标准化W与prov顺序。"""
    provs = list(coords.index)
    loc = coords.values.astype(float)
    d = np.sqrt(((loc[:, None, :] - loc[None, :, :]) ** 2).sum(2))
    np.fill_diagonal(d, np.inf)
    if kind == 'inv_dist':
        W = 1.0 / d
    elif kind == 'knear':
        W = np.zeros_like(d)
        for i in range(len(provs)):
            idx = np.argsort(d[i])[:k]
            W[i, idx] = 1.0
    elif kind == 'threshold':
        W = (d <= threshold).astype(float)
    else:
        raise ValueError(kind)
    np.fill_diagonal(W, 0)
    rowsum = W.sum(1, keepdims=True); rowsum[rowsum == 0] = 1
    W = W / rowsum
    return pd.DataFrame(W, index=provs, columns=provs), d

def morans_i(x, W, permutations=999, seed=42):
    provs = [p for p in x.index if p in W.index]
    v = x.loc[provs].astype(float)
    Wm = W.loc[provs, provs].values
    z = v.values - v.values.mean()
    n = len(v)
    I = n / Wm.sum() * (z @ Wm @ z) / (z @ z)
    EI = -1 / (n - 1)
    # 置换检验得到p值与z值（稳健）
    rng = np.random.default_rng(seed)
    perm = []
    vv = v.values.copy()
    for _ in range(permutations):
        vp = rng.permutation(vv)
        zp = vp - vp.mean()
        perm.append(n / Wm.sum() * (zp @ Wm @ zp) / (zp @ zp))
    perm = np.array(perm)
    pval = (np.sum(np.abs(perm - EI) >= abs(I - EI)) + 1) / (permutations + 1)
    zI = (I - perm.mean()) / perm.std() if perm.std() > 0 else np.nan
    return I, EI, zI, pval

# ---------- 马尔可夫链 ----------
def markov_transition(states, nstates=4):
    """states: dict prov -> sorted list of (year,state)。返回转移矩阵。"""
    P = np.zeros((nstates, nstates))
    for prov, seq in states.items():
        seq = sorted(seq)
        for (_, s0), (_, s1) in zip(seq[:-1], seq[1:]):
            P[int(s0) - 1, int(s1) - 1] += 1
    rowsum = P.sum(1, keepdims=True); rowsum[rowsum == 0] = 1
    return P / rowsum, P.sum()

print('econo_utils.py 已加载')
