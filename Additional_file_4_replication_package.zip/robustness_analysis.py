# -*- coding: utf-8 -*-
"""Rev4 稳健性分析：替代背离指数、连续DID+事件研究、改革后趋势、条件收敛、描述统计、带宽/状态数敏感性。
所有输出写入 results/robustness/，供手稿直接引用。"""
import numpy as np, pandas as pd, json, os, math
from econo_utils import gini, OLS, ols_cluster, kde, markov_transition

WD = 'D:/BaiduNetdiskDownload/年鉴分析/.workbuddy'
OUT = WD + '/results/robustness'
os.makedirs(OUT, exist_ok=True)
m = pd.read_csv(WD + '/master_panel.csv')
PHYS = '每万人拥有执业(助理)医师数(人)'
TECH = '每万人拥有卫生技术人员数(人)'
FISC = '财政卫生支出亿元'
FISCPC = '人均财政卫生支出'

def save(df, name):
    df.to_csv(OUT + '/' + name, index=False, encoding='utf-8-sig')

def hac(y, X, lag=2):
    """带 Newey-West HAC 标准误的 OLS；X 需含常数项。"""
    X = np.asarray(X, float); y = np.asarray(y, float)
    n = len(y)
    XtXi = np.linalg.pinv(X.T @ X)
    b = XtXi @ X.T @ y
    e = y - X @ b
    S = e[:, None] * X
    cov = S.T @ S
    for L in range(1, lag + 1):
        w = 1 - L / (lag + 1)
        G = S[L:].T @ S[:-L]
        cov += w * (G + G.T)
    cov = XtXi @ cov @ XtXi
    se = np.sqrt(np.diag(cov))
    t = b / se
    p = np.array([2 * (1 - 0.5 * (1 + math.erf(abs(v) / math.sqrt(2)))) for v in t])
    return b, se, t, p

def trend(series, years, lag=2):
    s = pd.Series(series).values.astype(float)
    yr = np.asarray(years, float)
    keep = np.isfinite(s) & np.isfinite(yr)
    b, se, t, p = hac(s[keep], np.column_stack([np.ones(keep.sum()), yr[keep] - yr[keep].min()]), lag)
    return dict(slope=float(b[1]), se=float(se[1]), t=float(t[1]), p=float(p[1]), n=int(keep.sum()))

def theil(x):
    x = np.asarray(x, float); x = x[np.isfinite(x) & (x > 0)]
    mu = x.mean()
    return float(np.mean(x / mu * np.log(x / mu)))

def spearman(a, b):
    s = pd.DataFrame({'a': a, 'b': b}).dropna()
    return float(np.corrcoef(s['a'].rank(), s['b'].rank())[0, 1])

def chi2_p_from_wald(W, df):
    """Wilson-Hilferty 近似卡方上尾概率。"""
    z = ((W / df) ** (1/3) - (1 - 2/(9*df))) / math.sqrt(2/(9*df))
    return float(1 - 0.5 * (1 + math.erf(z / math.sqrt(2))))

results = {}

# ============ 1. 替代背离指数构造 ============
print('=== 1. 替代背离指数 ===')
rows = []
for y in range(2008, 2025):
    d = m[m['年份'] == y][['prov', PHYS, TECH, FISC, FISCPC]].dropna(subset=['prov', PHYS, FISC])
    if len(d) < 28: continue
    a, f = d[PHYS].values, d[FISC].values
    ga, gf = gini(a), gini(f)
    ta, tf = theil(a), theil(f)
    sa = d.sort_values(FISC, ascending=False)['prov'].head(10)
    top_f = d[d['prov'].isin(sa)][FISC].sum() / f.sum()
    top_p = d[d['prov'].isin(sa)][PHYS].sum() / a.sum()
    # 卫生技术人员版本（2004 起可得）
    gte = np.nan
    if TECH in d and d[TECH].notna().sum() >= 28:
        gte = gini(d[TECH].values)
    rows.append({'年份': y, 'N': len(d), 'gini_phys': ga, 'gini_fisc': gf,
                 'gini_diff': gf - ga, 'gini_ratio': gf / ga,
                 'theil_phys': ta, 'theil_fisc': tf, 'theil_diff': tf - ta,
                 'rank_rho': spearman(a, f), 'rank_decoup': -spearman(a, f),
                 'fiscal_top10_share': top_f, 'phys_top10_same_share': top_p,
                 'top10_share_ratio': top_f / top_p,
                 'gini_fisc_minus_tech': gf - gte if np.isfinite(gte) else np.nan})
alt = pd.DataFrame(rows)
save(alt, 'alt_divergence.csv')
print(alt[['年份','gini_diff','theil_diff','rank_rho','gini_ratio','top10_share_ratio']].round(4).to_string(index=False))

alt_trends = {}
for col, sign in [('gini_diff', 1), ('theil_diff', 1), ('rank_decoup', 1),
                  ('gini_ratio', 1), ('top10_share_ratio', 1), ('rank_rho', -1)]:
    alt_trends[col] = trend(alt[col], alt['年份'])
results['alt_trends'] = alt_trends
print('趋势(HAC(2)):', json.dumps(alt_trends, indent=1, ensure_ascii=False))

# ============ 2. 改革后描述性趋势 + 卫生技术人员版 ITS ============
print('\n=== 2. 改革后趋势与可识别的ITS ===')
div = pd.read_csv(WD + '/results/table3_divergence.csv')
results['main_index_full_trend'] = trend(div['背离指数'], div['年份'])
post = div[div['年份'] >= 2009]
results['main_index_post_trend'] = trend(post['背离指数'], post['年份'])
results['main_pre_num_obs'] = int((div['年份'] < 2009).sum())
results['main_pre_years'] = div[div['年份'] < 2009]['年份'].tolist()

ht_rows = []
for y in range(2004, 2025):
    d = m[m['年份'] == y][['prov', TECH, FISC]].dropna()
    if len(d) < 28: continue
    ht_rows.append({'年份': y, 'N': len(d), 'gini_tech': gini(d[TECH].values),
                    'gini_fisc': gini(d[FISC].values),
                    'gap': gini(d[FISC].values) - gini(d[TECH].values)})
ht = pd.DataFrame(ht_rows)
save(ht, 'healthtech_gap.csv')
yr = ht['年份'].values.astype(float)
t = yr - 2004
post_d = (yr >= 2009).astype(float)
tpost = np.maximum(yr - 2009, 0)
X = np.column_stack([np.ones(len(ht)), t, post_d, tpost])
b, se, tv, pv = hac(ht['gap'].values, X, lag=2)
its_ht = {nm: dict(beta=float(bb), se=float(ss), t=float(tt), p=float(pp))
          for nm, bb, ss, tt, pp in zip(['intercept','pre_slope','level_shift','slope_change'], b, se, tv, pv)}
its_ht['N'] = len(ht); its_ht['pre_years'] = int((yr < 2009).sum())
results['its_healthtech'] = its_ht
print('卫生技术人员版ITS:', json.dumps(its_ht, indent=1, ensure_ascii=False))

# ============ 3. 连续 DID + 事件研究 ============
print('\n=== 3. 连续DID与事件研究 ===')
base = 2008
b0 = m[m['年份'] == base].set_index('prov')[PHYS].dropna()
z = (b0 - b0.mean()) / b0.std()
d = m[m['年份'].between(2000, 2024)].copy()
d['z'] = d['prov'].map(z)
d['post'] = (d['年份'] >= 2009).astype(float)
d['z_post'] = d['z'] * d['post']
d['y_fisc'] = np.log(d[FISCPC])
d['y_phys'] = np.log(d[PHYS])
did_res = {}
for out in ['y_fisc', 'y_phys']:
    mod, names, dd = ols_cluster(d, out, ['z_post'], cluster='prov', add_fe=['prov', '年份'])
    i = names.index('z_post')
    did_res[out] = dict(beta=float(mod.beta[i]), se=float(mod.se[i]), t=float(mod.t[i]),
                        p=float(mod.p[i]), N=int(len(dd)), clusters=int(dd['prov'].nunique()))
results['continuous_did'] = did_res
print('连续DID:', json.dumps(did_res, indent=1, ensure_ascii=False))

# 事件研究（主结果：人均财政卫生支出；基期 2008）
ev_years = sorted(d['年份'].dropna().unique())
for yr_ in ev_years:
    d[f'z_{yr_}'] = d['z'] * (d['年份'] == yr_)
ev_vars = [f'z_{yr_}' for yr_ in ev_years if yr_ != base]
mod_e, names_e, dd_e = ols_cluster(d, 'y_fisc', ev_vars, cluster='prov', add_fe=['prov', '年份'])
ev_rows = []
pre_idx = []
for nm in ev_vars:
    i = names_e.index(nm)
    yr_ = int(nm[2:])
    ev_rows.append({'年份': yr_, 'beta': float(mod_e.beta[i]), 'se': float(mod_e.se[i]),
                    't': float(mod_e.t[i]), 'lo': float(mod_e.beta[i]-1.96*mod_e.se[i]),
                    'hi': float(mod_e.beta[i]+1.96*mod_e.se[i])})
    if yr_ < base: pre_idx.append(i)
ev = pd.DataFrame(ev_rows).sort_values('年份')
save(ev, 'event_study_continuous.csv')
W = mod_e.beta[pre_idx] @ np.linalg.pinv(mod_e.cov[np.ix_(pre_idx, pre_idx)]) @ mod_e.beta[pre_idx]
results['event_prewald'] = dict(W=float(W), df=len(pre_idx), p=chi2_p_from_wald(W, len(pre_idx)))
results['event_base_year'] = base
print('事件研究事前联合检验:', results['event_prewald'])
print(ev.round(3).to_string(index=False))

# ============ 4. 条件收敛 ============
print('\n=== 4. 条件收敛 ===')
pop = '年末常住人口(万人)'
def gdp_pc(year):
    g = m[m['年份'] == year].set_index('prov')['地区生产总值(亿元)']
    p = m[m['年份'] == year].set_index('prov')[pop]
    return g * 1e4 / p
pv = m.pivot(index='prov', columns='年份', values=PHYS)
cond = {}
for y0, y1, extra in [(2001, 2024, None), (2009, 2024, 'aging')]:
    gp = gdp_pc(y0)
    df = pd.DataFrame({'g': np.log(pv[y1] / pv[y0]), 'y0': np.log(pv[y0]), 'gdp0': np.log(gp)})
    if extra:
        df['aging0'] = m[m['年份'] == y0].set_index('prov')['老年人口抚养比(人口抽样调查)(%)']
    df = df.dropna()
    X = np.column_stack([np.ones(len(df)), df['y0'], df['gdp0']] +
                        ([df['aging0']] if extra else []))
    mm = OLS(X, df['g'].values)
    nms = ['const', 'ln_initial_phys', 'ln_initial_gdp_pc'] + (['aging_ratio'] if extra else [])
    cond[f'{y0}-{y1}'] = {nm: dict(beta=float(bb), se=float(ss), t=float(tt), p=float(pp))
                          for nm, bb, ss, tt, pp in zip(nms, mm.beta, mm.se, mm.t, mm.p)}
    cond[f'{y0}-{y1}']['N'] = len(df); cond[f'{y0}-{y1}']['R2'] = float(mm.r2)
results['conditional_convergence'] = cond
print(json.dumps(cond, indent=1, ensure_ascii=False))

# ============ 5. KDE 带宽与马尔可夫状态数敏感性 ============
print('\n=== 5. 小样本稳健性 ===')
kder = []
for y in [1990, 2009, 2024]:
    x = m[m['年份'] == y][PHYS].dropna().values
    bw0 = kde(x)[2]
    grid = np.linspace(0, 60, 1200)
    for f in [0.5, 1.0, 2.0]:
        g, dens, bw = kde(x, grid=grid, bw=bw0 * f)
        kder.append({'年份': y, 'bandwidth_factor': f, 'bandwidth': bw,
                     'mode': float(g[np.argmax(dens)]), 'N': len(x)})
kde_df = pd.DataFrame(kder); save(kde_df, 'kde_bandwidth_sensitivity.csv')
results['kde_modes'] = kder

mr = []
for ns in [3, 4, 5]:
    q = np.nanpercentile(pv.values, np.arange(1, ns) * 100 / ns)
    def st(v):
        if not np.isfinite(v): return None
        return int(np.searchsorted(q, v, side='right') + 1)
    states = {}
    for prov in pv.index:
        seq = [(int(yy), st(pv.loc[prov, yy])) for yy in pv.columns if np.isfinite(pv.loc[prov, yy])]
        states[prov] = [(yy, s) for yy, s in seq if s is not None and 1 <= s <= ns]
    P, cnt = markov_transition(states, ns)
    mr.append({'states': ns, 'diagonal': [float(v) for v in np.diag(P)],
               'transitions': float(cnt)})
results['markov_sensitivity'] = mr
save(pd.DataFrame([{'states': r['states'], 'diagonal': ';'.join(f'{v:.3f}' for v in r['diagonal']),
                    'transitions': r['transitions']} for r in mr]), 'markov_state_sensitivity.csv')
print('KDE modes:', kde_df.round(3).to_string(index=False))
print('Markov:', mr)

# ============ 6. 描述统计与相关矩阵 ============
print('\n=== 6. 描述统计 ===')
desc_vars = [(PHYS, 'Physicians per 10,000'), (TECH, 'Health technicians per 10,000'),
             ('每万人拥有注册护士数(人)', 'Nurses per 10,000'),
             ('每万人医疗机构床位数(张)', 'Beds per 10,000'),
             (FISC, 'Fiscal health spending (100m CNY)'),
             (FISCPC, 'Fiscal health spending per capita (CNY)'),
             ('地区生产总值(亿元)', 'GDP (100m CNY)'),
             ('老年人口抚养比(人口抽样调查)(%)', 'Old-age dependency ratio (%)'),
             ('城镇化率', 'Urbanization rate (%)'), ('护医比', 'Nurse-physician ratio')]
desc = []
for c, lab in desc_vars:
    s = m[c].dropna()
    desc.append({'Variable': lab, 'N': len(s), 'Mean': s.mean(), 'SD': s.std(),
                 'Min': s.min(), 'Max': s.max(), 'Years': f"{m[m[c].notna()]['年份'].min()}-{m[m[c].notna()]['年份'].max()}"})
desc_df = pd.DataFrame(desc); save(desc_df, 'descriptives.csv')
sub = m[m['年份'].between(2008, 2024)]
cvars = [PHYS, FISCPC, '地区生产总值(亿元)', '老年人口抚养比(人口抽样调查)(%)', '城镇化率']
clabs = ['Physician density','Fiscal spending pc','GDP','Old-age dep.','Urbanization']
cm = sub[cvars].corr(); cm.index = clabs; cm.columns = clabs
cm.round(3).to_csv(OUT + '/correlation_matrix.csv', encoding='utf-8-sig')
print(desc_df.round(2).to_string(index=False)); print(cm.round(2))

json.dump(results, open(OUT + '/robustness_results.json','w',encoding='utf-8'),
          ensure_ascii=False, indent=2)
print('\n完成，输出目录：', OUT)
