# -*- coding: utf-8 -*-
"""
构建统一省级面板：六源年鉴整合
数据源：
  1. 中国统计年鉴面板 (tidy_stat.csv) —— 人口/GDP/财政卫生支出/医师密度/服务量/预期寿命
  2. 中国财政年鉴面板 (原始xlsx) —— 医疗卫生支出(2007前后口径)/中央补助/一般预算收支/人均财政
  3. 中国卫生健康统计年鉴 (逐版zip) —— 每千人口卫技/医师/护士精确值 (health_staff_panel_clean.csv)
  4. 中国教育统计年鉴面板 —— 高等医药院校本专科毕业生/招生/在校生 (人才管道)
  5. 中国人口和就业统计年鉴 —— 各地区老年抚养比、预期寿命
  6. 中国民政统计年鉴 —— 养老机构床位
输出：master_panel.csv + 数据字典 + 质量报告
"""
import pandas as pd, numpy as np, openpyxl, zipfile, io, re, glob, os, warnings
warnings.filterwarnings('ignore')

BASE = r'D:/BaiduNetdiskDownload/年鉴分析'
WD   = BASE + '/.workbuddy'

PROVS = ['北京','天津','河北','山西','内蒙古','辽宁','吉林','黑龙江','上海','江苏','浙江',
         '安徽','福建','江西','山东','河南','湖北','湖南','广东','广西','海南','重庆','四川',
         '贵州','云南','西藏','陕西','甘肃','青海','宁夏','新疆']

def clean_prov(x):
    """把各种省份写法统一为简称。"""
    if x is None: return None
    s = str(x).replace(' ','').replace('\u3000','').strip()
    for p in PROVS:
        if p in s: return p
    m = {'北京市':'北京','天津市':'天津','上海市':'上海','重庆市':'重庆',
         '广西壮族自治区':'广西','内蒙古自治区':'内蒙古','西藏自治区':'西藏',
         '宁夏回族自治区':'宁夏','新疆维吾尔自治区':'新疆'}
    return m.get(s)

def tonum(v):
    try:
        f=float(v)
        return f if np.isfinite(f) else np.nan
    except: return np.nan

# ============ 源1：统计年鉴（已抽取的 tidy_stat.csv） ============
stat = pd.read_csv(WD+'/tidy_stat.csv')
stat['年份'] = pd.to_numeric(stat['年份'], errors='coerce')
stat['prov'] = stat['地区'].map(clean_prov)
stat = stat[stat['prov'].notna() & stat['年份'].notna()].copy()
stat['年份'] = stat['年份'].astype(int)
# 保留数值列
keep1 = ['prov','年份','年末常住人口(万人)','地区生产总值(亿元)','地方财政一般预算支出(亿元)',
         '地方财政医疗卫生支出(亿元)','地方财政教育支出(亿元)','每万人拥有执业(助理)医师数(人)',
         '每万人拥有注册护士数(人)','每万人医疗机构床位数(张)','每万人拥有卫生技术人员数(人)',
         '医院病床使用率(%)','医院平均住院日(日)','平均预期寿命(岁)','人口死亡率(‰)',
         '人口出生率(‰)','城镇人口(万人)','城镇基本医疗保险年末参保人数(万人)',
         '医疗卫生机构诊疗人次(亿次)','医疗卫生机构出院人数(万人)']
extra1 = ['65岁及以上人口数(人口抽样调查)(人)','老年人口抚养比(人口抽样调查)(%)',
          '总抚养比(人口抽样调查)(%)','少年儿童抚养比(人口抽样调查)(%)']
# 从独立提取的 aging_panel 合并（tidy_stat 未含这些列）
ag = pd.read_csv(WD+'/aging_panel.csv')
stat = stat.merge(ag, on=['prov','年份'], how='left')
# 年龄结构派生
stat['老年人口占比'] = stat['65岁及以上人口数(人口抽样调查)(人)']/(stat['年末常住人口(万人)']*1e4)
print('源1 统计年鉴:', stat.shape, '| 老年抚养比有效', stat['老年人口抚养比(人口抽样调查)(%)'].notna().sum())

# ============ 源2：财政年鉴（长表 -> 宽表） ============
fp = r'D:/BaiduNetdiskDownload/年鉴分析/014-26.中国财政年鉴【全套】/02.面板数据/【数据年份2000-2021】中国财政年鉴31省面板数据.xlsx'
wb = openpyxl.load_workbook(fp, read_only=True, data_only=True); ws = wb['原始数据']
it = ws.iter_rows(values_only=True); hdr = list(next(it))
year_cols = {int(h):i for i,h in enumerate(hdr) if isinstance(h,(int,float)) and 2000<=int(h)<=2021}
fin_rows=[]
# 目标指标（关键词匹配）
fin_targets = {
    '财政医疗卫生支出_万元': '决算数-支出-2007年及之后统计口径-医疗卫生',
    '财政医疗卫生支出_旧口径_万元': '决算数-支出-2007年前统计口径-医疗卫生支出',
    '中央补助收入_万元': '决算数-收入-中央补助收入',
    '一般预算支出总计_万元': '决算数-支出-支出总计',
    '一般预算收入合计_万元': '决算数-收入-本年收入合计',
    '财政支出_亿元': '财政支出及占全国和地方支出比重-财政支出_亿元',
    '财政收入_亿元': '财政收入及占全国和地方收入比重-财政收入_亿元',
    '人均财政支出_元': '人均财政支出每人平均_元/人',
    '人均财政收入_元': '人均财政收入数额每人平均_元/人',
    '财政教育支出_万元': '决算数-支出-2007年及之后统计口径-教育_万元',
    '财政社保就业支出_万元': '决算数-支出-2007年及之后统计口径-社会保障和就业_万元',
}
for r in it:
    prov = clean_prov(r[1]); ind = str(r[4]) if r[4] else ''
    if not prov: continue
    for outname, kw in fin_targets.items():
        if kw in ind:
            for y,ci in year_cols.items():
                v = tonum(r[ci])
                if not np.isnan(v): fin_rows.append({'prov':prov,'年份':y,'fin_'+outname:v})
            break
wb.close()
fin_long = pd.DataFrame(fin_rows)
# 口径拼接：2007前用旧口径，2007+用新口径
hl = fin_long.pivot_table(index='prov',columns='年份',values='fin_财政医疗卫生支出_万元',aggfunc='first')
ho = fin_long.pivot_table(index='prov',columns='年份',values='fin_财政医疗卫生支出_旧口径_万元',aggfunc='first')
hcomb = hl.combine_first(ho)  # 优先新口径，缺失用旧口径
# 转成 prov-年 长表
hcomb.columns = hcomb.columns.astype(int)
hstack = hcomb.stack().rename('fin_财政医疗卫生支出_合并_万元').reset_index()
hstack.columns = ['prov','年份','fin_财政医疗卫生支出_合并_万元']
fin_w = fin_long.pivot_table(index=['prov','年份'], values=[c for c in fin_long.columns if c.startswith('fin_')], aggfunc='first').reset_index()
fin_w = fin_w.merge(hstack, on=['prov','年份'], how='outer')
print('源2 财政年鉴:', fin_w.shape, '卫生支出合并有效', fin_w['fin_财政医疗卫生支出_合并_万元'].notna().sum())

# ============ 源3：卫生统计年鉴精确人力面板 ============
h = pd.read_csv(WD+'/health_staff_panel_clean.csv')
h = h.rename(columns={'prov':'prov','年份':'年份'})[['prov','年份','卫技人员每千人','执业医师每千人','注册护士每千人','护医比']]
h = h.drop_duplicates(['prov','年份'])
print('源3 卫生人力:', h.shape, '年份', sorted(h['年份'].unique()))

# ============ 源4：教育年鉴（医药院校人才管道） ============
ep = r'D:/BaiduNetdiskDownload/年鉴分析/012-更26.中国教育统计年鉴【全套】/02.面板数据/【数据年份2000-2023】中国教育统计年鉴31省面板数据.xlsx'
wb = openpyxl.load_workbook(ep, read_only=True, data_only=True); ws = wb['原始数据']
it = ws.iter_rows(values_only=True); ehdr = list(next(it))
edu_idx = {}
for i,hname in enumerate(ehdr):
    s=str(hname)
    if '高等医药院校本、专科学生数-毕(结)业生数' in s: edu_idx[i]='edu_医药院校毕业生'
    elif '高等医药院校本、专科学生数-招生数(人)' in s: edu_idx[i]='edu_医药院校招生'
    elif '高等医药院校本、专科学生数-在校生数(人)' in s: edu_idx[i]='edu_医药院校在校生'
    elif s=='研究生毕(结)业生数(人)': edu_idx.setdefault(i,'edu_研究生毕业生')
edu_rows=[]
for r in it:
    prov=clean_prov(r[1])
    if not prov: continue
    y=r[0]
    try: y=int(y)
    except: continue
    d={'prov':prov,'年份':y}
    for i,name in edu_idx.items(): d[name]=tonum(r[i])
    edu_rows.append(d)
wb.close()
edu = pd.DataFrame(edu_rows)
edu = edu.drop_duplicates(['prov','年份'])
print('源4 教育年鉴:', edu.shape, {c:int(edu[c].notna().sum()) for c in edu.columns if c.startswith('edu_')})

# ============ 源5：人口就业年鉴（普查年份预期寿命：1990/2000/2010/2020） ============
zpp = r'D:/BaiduNetdiskDownload/年鉴分析/019-26.中国人口和就业统计年鉴【全套】/EXCEL/2007-2025【中国人口和就业统计年鉴】/中国人口和就业统计年鉴2024（excel）.zip'
pop_rows=[]
with zipfile.ZipFile(zpp) as z:
    name='第1部分 综合数据/1-10_各地区人口平均预期寿命.xlsx'
    if name in z.namelist():
        with z.open(name) as f:
            wb=openpyxl.load_workbook(io.BytesIO(f.read()),read_only=True,data_only=True); ws=wb[wb.sheetnames[0]]
            data=list(ws.iter_rows(values_only=True)); wb.close()
        # 表头行5(索引4)含各普查年标签，如 "1990年预期寿命..."
        hdrrow = data[4]
        year_map={}
        for ci,c in enumerate(hdrrow):
            mm=re.search(r'((?:19|20)\d{2})年预期寿命', str(c))
            if mm: year_map[ci]=int(mm.group(1))
        # 数据行：第7行起（索引6），列0为地区，每普查年取两列（男/女）的均值位置即首列
        for row in data[6:]:
            if not row or not row[0]: continue
            prov=clean_prov(row[0])
            if not prov or prov=='全国': continue
            for ci,yr in year_map.items():
                tot = tonum(row[ci]) if ci<len(row) else np.nan
                male= tonum(row[ci+1]) if ci+1<len(row) else np.nan
                fem = tonum(row[ci+2]) if ci+2<len(row) else np.nan
                # 表内是 总/男/女 三列，取总列
                val = tot if not np.isnan(tot) else (np.nanmean([male,fem]) if not(np.isnan(male) or np.isnan(fem)) else np.nan)
                if not np.isnan(val) and 60<val<95:
                    pop_rows.append({'prov':prov,'年份':yr,'pop_预期寿命':val})
pop = pd.DataFrame(pop_rows).drop_duplicates(['prov','年份']) if pop_rows else pd.DataFrame(columns=['prov','年份','pop_预期寿命'])
print('源5 人口就业(普查年预期寿命):', pop.shape, '年份', sorted(pop['年份'].unique()) if len(pop) else '-')

# ============ 源6：民政年鉴（养老机构数，2024分地区） ============
civil_rows=[]
zpm = r'D:/BaiduNetdiskDownload/年鉴分析/022-26.中国民政统计年鉴【全套】/EXCEL/中国民政统计年鉴2024（excel）.zip'
with zipfile.ZipFile(zpm) as z:
    name='第5部分当年分地区统计资料/02 民政服务/提供住宿的民政服务/C-2-3_养老机构总表.xlsx'
    if name in z.namelist():
        with z.open(name) as f:
            wb=openpyxl.load_workbook(io.BytesIO(f.read()),read_only=True,data_only=True); ws=wb[wb.sheetnames[0]]
            data=list(ws.iter_rows(values_only=True)); wb.close()
        for row in data:
            if not row or not row[0]: continue
            prov=clean_prov(row[0])
            if not prov or prov=='全国': continue
            units=tonum(row[1]) if len(row)>1 else np.nan
            civil_rows.append({'prov':prov,'年份':2024,'civil_养老机构数':units})
civil = pd.DataFrame(civil_rows).drop_duplicates(['prov','年份']) if civil_rows else pd.DataFrame(columns=['prov','年份','civil_养老机构数'])
print('源6 民政(2024养老机构数):', civil.shape)

# ============ 合并 ============
master = stat.copy()
for df in [fin_w, h, edu, pop, civil]:
    if len(df): master = master.merge(df, on=['prov','年份'], how='outer')
master = master[(master['prov'].notna()) & (master['年份'].notna()) & (master['年份'].between(1990,2024))].copy()
master['年份']=master['年份'].astype(int)
master = master.sort_values(['prov','年份']).reset_index(drop=True)

# 构造核心分析变量
master['财政卫生支出亿元'] = master['fin_财政医疗卫生支出_合并_万元']/10000  # 万元->亿元
master['财政卫生支出亿元'] = master['财政卫生支出亿元'].fillna(master['地方财政医疗卫生支出(亿元)'])
# 人均财政卫生支出(元)
master['人均财政卫生支出'] = master['财政卫生支出亿元']*1e8/(master['年末常住人口(万人)']*1e4)
# 财政分权：地方财政支出/(地方+中央)近似用 地方预算支出/GDP
master['财政卫生支出占GDP比重'] = master['财政卫生支出亿元']/master['地区生产总值(亿元)']
# 城镇化率
master['城镇化率'] = master['城镇人口(万人)']/master['年末常住人口(万人)']
# 服务强度
master['诊疗人次_percap'] = master['医疗卫生机构诊疗人次(亿次)']*1e8/(master['年末常住人口(万人)']*1e4)

master.to_csv(WD+'/master_panel.csv', index=False, encoding='utf-8-sig')
print('\n===== 统一面板 =====')
print('形状', master.shape, '省份', master['prov'].nunique(), '年份', int(master['年份'].min()),'-',int(master['年份'].max()))
print('\n各核心变量有效观测/年份:')
for c in ['年末常住人口(万人)','地区生产总值(亿元)','财政卫生支出亿元','人均财政卫生支出',
          '每万人拥有执业(助理)医师数(人)','执业医师每千人','注册护士每千人','护医比',
          'edu_医药院校毕业生','pop_预期寿命','平均预期寿命(岁)','城镇化率','医院病床使用率(%)']:
    if c in master.columns:
        s=master[['年份',c]].dropna()
        print(f'  {c[:22]:24s} n={len(s):4d} 年={int(s["年份"].min()) if len(s) else "-"}-{int(s["年份"].max()) if len(s) else "-"}')
print('\n已保存 master_panel.csv')
