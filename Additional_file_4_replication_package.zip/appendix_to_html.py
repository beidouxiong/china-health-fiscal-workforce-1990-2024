# -*- coding: utf-8 -*-
"""把 online_appendix_en.md 转成与正文同风格的 HTML（供 html-to-doc 转换）。"""
import re, html as htmlmod

SRC = 'D:/BaiduNetdiskDownload/年鉴分析/.workbuddy/online_appendix_en.md'
DST = 'D:/BaiduNetdiskDownload/年鉴分析/.workbuddy/online_appendix_en.html'
lines = open(SRC, encoding='utf-8').read().splitlines()

def inline(s):
    s = htmlmod.escape(s)
    s = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', s)
    s = re.sub(r'(?<!\*)\*([^*]+?)\*(?!\*)', r'<em>\1</em>', s)
    s = re.sub(r'`([^`]+?)`', r'<code>\1</code>', s)
    # <br> 需要保留为换行
    s = s.replace('&lt;br&gt;', '<br/>')
    return s

out = []
i = 0
n = len(lines)
first_h1 = False
while i < n:
    ln = lines[i].rstrip()
    if not ln.strip():
        i += 1; continue
    if re.match(r'^---+$', ln.strip()):
        i += 1; continue
    m = re.match(r'^(#{1,4})\s+(.*)', ln)
    if m:
        lvl = len(m.group(1)); txt = m.group(2).strip()
        if lvl == 1 and not first_h1:
            first_h1 = True; i += 1; continue
        tag = f'h{min(lvl,4)}'
        out.append(f'<{tag}>{inline(txt)}</{tag}>'); i += 1; continue
    # 表格：以 | 开头，找连续行
    if ln.startswith('|'):
        tbl = []
        while i < n and lines[i].strip().startswith('|'):
            tbl.append(lines[i].strip()); i += 1
        # 第二行是分隔行
        rows = []
        for j, r in enumerate(tbl):
            cells = [c.strip() for c in r.strip('|').split('|')]
            if j == 1 and all(re.match(r'^:?-{2,}:?$', c) for c in cells):
                continue
            tag = 'th' if j == 0 else 'td'
            rows.append('<tr>' + ''.join(f'<{tag}>{inline(c)}</{tag}>' for c in cells) + '</tr>')
        out.append('<table>' + ''.join(rows) + '</table>')
        continue
    # 普通段落：合并连续非空非特殊行
    para = [ln]; i += 1
    while i < n and lines[i].strip() and not lines[i].strip().startswith('#') and not lines[i].strip().startswith('|'):
        para.append(lines[i].strip()); i += 1
    out.append('<p>' + inline(' '.join(para)) + '</p>')

body = '\n'.join(out)
title = "Online Appendix — Convergence Without Equalization"
doc = f'''<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/>
<title>{htmlmod.escape(title)}</title>
<style>
@page {{ size: A4; margin: 2.2cm 2cm; }}
body {{ font-family: "Times New Roman", Georgia, serif; font-size: 11.5pt; line-height: 1.5; color:#111; max-width:100%; }}
h1.title {{ font-size: 18pt; text-align:center; font-weight:bold; margin-bottom:18pt; }}
h2 {{ font-size: 13.5pt; font-weight:bold; margin-top:18pt; margin-bottom:8pt; border-bottom:0.5pt solid #888; padding-bottom:3pt;}}
h3 {{ font-size: 12pt; font-weight:bold; margin-top:13pt; margin-bottom:5pt;}}
p {{ margin: 6pt 0; text-align:justify; }}
table {{ border-collapse: collapse; width:100%; margin:10pt 0; font-size: 9pt; }}
th,td {{ border: 0.5pt solid #777; padding: 3pt 5pt; text-align:left; }}
th {{ background:#eef2f7; font-weight:bold; }}
code {{ font-family: Consolas, monospace; font-size: 10pt; }}
strong {{ font-weight:bold; }}
</style></head>
<body>
{body}
</body></html>'''
open(DST, 'w', encoding='utf-8').write(doc)
print('HTML已生成', DST, '长度', len(doc), '表格数', body.count('<table>'))
