# -*- coding: utf-8 -*-
"""Q1 专项诊断：背离指数能否回推至 2001 年并使 ITS 重新可识别？
输出 results/q1/ 下的序列、ITS 多规格结果与敏感性检验。"""
import numpy as np, pandas as pd, json, os, math
from econo_utils import gini

WD = 'D:/BaiduNetdiskDownload/年鉴分析/.workbuddy'
OUT = WD + '/results/q1'
os.makedirs(OUT, exist_ok=True)
m = pd.read_csv(WD + '/master_panel.csv')
PHYS = '每万人拥有执业(助理)医师数(人)'
FISC = '财政卫生支出亿元'

def hac(y, X, lag=2):
    X=np.asarray(X,float); y=np.asarray(y,float); n=len(y)
    XtXi=np.linalg.pinv(X.T@X); b=XtXi@X.T@y; e=y-X@b
    S=e[:,None]*X; cov=S.T@S
    for L in range(1,lag+1):
        w=1-L/(lag+1); G=S[L:].T@S[:-L]; cov+=w*(G+G.T)
    cov=XtXi@cov@XtXi
    se=np.sqrt(np.diag(cov)); t=np.divide(b,se,out=np.zeros_like(b),where=se>0)
    p=np.array([2*(1-0.5*(1+math.erf(abs(v)/math.sqrt(2)))) for v in t])
    return b,se,t,p

res={}

# ---------- 1. 扩展背离指数 2001-2024 ----------
rows=[]
for y in range(2000,2025):
    a=m[m['年份']==y][PHYS].dropna(); b=m[m['年份']==y][FISC].dropna()
    if len(a)>=28 and len(b)>=28:
        rows.append({'年份':y,'医师基尼':gini(a.values),'财政基尼':gini(b.values),
                     '背离指数':gini(b.values)-gini(a.values),'口径':0 if y<=2006 else 1})
div=pd.DataFrame(rows)
div.to_csv(OUT+'/divergence_extended.csv',index=False,encoding='utf-8-sig')
res['extended_years']=int(div['年份'].min())
res['n_pre_reform']=int((div['年份']<2009).sum())
res['pre_years']=[int(y) for y in div[div['年份']<2009]['年份']]
res['pre_by_accounting']={'old_2001_2006':[int(y) for y in div[(div['年份']<2009)&(div['口径']==0)]['年份']],
                          'new_2007_2008':[int(y) for y in div[(div['年份']<2009)&(div['口径']==1)]['年份']]}
print('扩展序列:',res['pre_years'],'改革前点数',res['n_pre_reform'])

# ---------- 2. 全期趋势（旧 vs 新起点） ----------
def trend(d, lag=2):
    yr=d['年份'].values.astype(float); y=d['背离指数'].values
    b,se,t,p=hac(y,np.column_stack([np.ones(len(y)),yr-yr.min()]),lag)
    return dict(slope=float(b[1]),se=float(se[1]),t=float(t[1]),p=float(p[1]),n=len(y),
                first=int(yr.min()),last=int(yr.max()))
res['trend_extended_2001_2024']=trend(div)
res['trend_original_2008_2024']=trend(div[div['年份']>=2008])
res['trend_post_2009_2024']=trend(div[div['年份']>=2009])
for k in ['trend_extended_2001_2024','trend_original_2008_2024','trend_post_2009_2024']:
    print(k,res[k])

# ---------- 3. ITS 多规格 ----------
def its(d, specs, label):
    yr=d['年份'].values.astype(float); y=d['背离指数'].values
    t=yr-2009
    post=(yr>=2009).astype(float)
    cols={'1':np.ones(len(y)),'t':t,'post':post,'post_t':post*t,
          'acct':(yr>=2007).astype(float),'acct_t':((yr>=2007).astype(float))*(yr-2007)}
    X=np.column_stack([cols[s] for s in specs])
    b,se,tv,p=hac(y,X,lag=2)
    out={'spec':''.join(specs),'n':len(y),'years':[int(yr.min()),int(yr.max())],
         'coef':{s:{'b':float(bb),'se':float(ss),'t':float(tt),'p':float(pp)}
                 for s,bb,ss,tt,pp in zip(specs,b,se,tv,p)}}
    res['its_'+label]=out
    print('\nITS',label,out['spec'],'n=',out['n'])
    for s in specs:
        c=out['coef'][s]; print('  %-7s b=%+.4f se=%.4f t=%+.2f p=%.4f'%(s,c['b'],c['se'],c['t'],c['p']))
    return out

# Spec A: 原稿式分段（无口径控制），2001-2024
its(div,['1','t','post','post_t'],'A_no_accounting_2001_2024')
# Spec B: 加口径水平虚拟变量
its(div,['1','t','post','post_t','acct'],'B_with_accounting_dummy')
# Spec C: 加口径虚拟变量+口径后趋势（口径可能改变斜率）
its(div,['1','t','post','post_t','acct','acct_t'],'C_accounting_level_and_slope')
# Spec D: 排除2008（唯一新口径事前点），只用2001-2004 vs 2009-2024
its(div[div['年份']!=2008],['1','t','post','post_t','acct'],'D_exclude_2008')
# Spec E: 新口径一致样本 2008-2024（原稿诚实版，事前仅1点）
its(div[div['年份']>=2008],['1','t','post','post_t'],'E_new_accounting_only')

# ---------- 4. 共线性与识别诊断 ----------
d=div.copy(); yr=d['年份'].values
D07=(yr>=2007).astype(float); D09=(yr>=2009).astype(float)
res['identification']={
 'corr_D07_D09':float(np.corrcoef(D07,D09)[0,1]),
 'n_pre_new_accounting':int(((yr<2009)&(D07==1)).sum()),
 'pre_new_accounting_years':[int(y) for y in yr[(yr<2009)&(D07==1)]],
 'n_pre_old_accounting':int(((yr<2009)&(D07==0)).sum()),
 'gap_2004_to_2008':4,
}
print('\n识别诊断:',res['identification'])

# ---------- 5. 改革前趋势的样本敏感性（4个旧口径点 leave-one-out） ----------
pre=div[(div['年份']>=2001)&(div['年份']<=2004)]
loo=[]
for drop in pre['年份']:
    dd=pre[pre['年份']!=drop]
    v=trend(dd)
    loo.append({'dropped':int(drop),'slope':v['slope'],'t':v['t']})
res['pre_trend_loo']=loo
# 含2008的改革前趋势
pre2=div[div['年份']<2009]
res['pre_trend_with_2008']=trend(pre2)
res['pre_trend_2001_2004_only']=trend(pre)
print('\n事前趋势 2001-2004:',res['pre_trend_2001_2004_only'])
print('事前趋势 含2008:',res['pre_trend_with_2008'])
print('LOO:',loo)

# ---------- 6. 口径效应幅度 vs 医改效应 ----------
fg=pd.read_csv(WD+'/results/table1_gini_series.csv')
fg=fg[fg['指标']=='财政卫生支出'].set_index('年份')['基尼系数']
g06=float(fg.loc[2006]); g07=float(fg.loc[2007])
res['accounting_jump']={'fiscal_gini_2006':g06,'fiscal_gini_2007':g07,'jump':g07-g06}
print('\n口径跳跃 2006->2007 财政基尼:',res['accounting_jump'])
# 医师基尼无 2005-2007，故口径跳跃无法用背离指数同口径观测校验
res['accounting_confounded_reason']='医师密度2005-2007完全缺失且无替代序列，口径跳跃年(2007)无医师观测，故口径效应与医改效应在2008单点上完全混淆'

json.dump(res,open(OUT+'/q1_results.json','w',encoding='utf-8'),ensure_ascii=False,indent=1)
print('\n已写入',OUT+'/q1_results.json')
